"""Application-wide configuration and tunable thresholds."""

import os

APP_NAME = "AI Data Detective"
APP_ICON = "assets/logo.png"

MAX_UPLOAD_SIZE_MB = 200
MAX_ROWS_FOR_FULL_VISUALIZATION = 50_000
VISUALIZATION_SAMPLE_SIZE = 20_000

SUPPORTED_EXTENSIONS = (".csv", ".xlsx", ".xls")

# Missingness bands, expressed as a percentage of rows.
MISSING_LOW_THRESHOLD = 5.0
MISSING_MODERATE_THRESHOLD = 20.0

# A column is treated as near-constant when the dominant value covers this
# share of non-null rows or more.
NEAR_CONSTANT_THRESHOLD = 0.98

# A column is flagged as high-cardinality once unique values exceed this
# share of total rows, provided it also clears MIN_HIGH_CARDINALITY_UNIQUE.
HIGH_CARDINALITY_RATIO = 0.9
MIN_HIGH_CARDINALITY_UNIQUE = 20

# Correlation strength cutoffs.
STRONG_CORRELATION_THRESHOLD = 0.7
MODERATE_CORRELATION_THRESHOLD = 0.4

# Outlier detection.
IQR_MULTIPLIER = 1.5
ZSCORE_THRESHOLD = 3.0
ISOLATION_FOREST_CONTAMINATION = "auto"

# Clustering.
MIN_ROWS_FOR_CLUSTERING = 20
MAX_KMEANS_K = 8
DBSCAN_MIN_SAMPLES = 5

# Machine learning.
MIN_ROWS_FOR_ML = 30
TEST_SIZE = 0.2
RANDOM_STATE = 42
CLASSIFICATION_MAX_UNIQUE_TARGET = 20

REPORTS_DIR = "reports"
UPLOADS_DIR = "data/uploads"

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
