"""Dashboard page: a quick investigation summary of the whole dataset."""

import streamlit as st

from config.config import APP_NAME
from modules.anomaly_detection import run_automatic_anomaly_detection
from modules.clustering import is_clustering_suitable
from modules.correlation_analysis import compute_correlation_matrix, find_significant_relationships
from modules.data_loader import LoadedDataset
from modules.data_profiler import build_overview
from modules.data_quality import run_full_quality_analysis
from modules.pattern_detection import run_pattern_detection
from modules.prediction import is_ml_feasible


def render_empty_state() -> None:
    st.title(APP_NAME)
    st.write(
        "Upload a CSV or Excel dataset from the sidebar to start an automatic investigation. "
        "The application will profile your data, check its quality, surface correlations and "
        "anomalies, detect patterns, and offer clustering and machine learning where appropriate."
    )
    st.markdown(
        """
        **What this application does:**
        - Loads and validates your dataset, handling common formatting problems.
        - Runs a full data-quality check and produces a transparent health score.
        - Calculates statistics and generates exploratory visualizations automatically.
        - Detects correlations, anomalies, and statistical patterns.
        - Performs clustering and, when a target column is selected, classification or regression.
        - Summarizes everything into plain-language insights and a downloadable report.
        """
    )


def render(dataset: LoadedDataset) -> None:
    st.header("Investigation Summary")

    df = dataset.dataframe
    column_types = dataset.column_types

    overview = build_overview(df, column_types)

    outlier_ratio = 0.0
    anomaly_results = None
    if column_types.numerical:
        anomaly_results = run_automatic_anomaly_detection(df, column_types.numerical)
        outlier_ratio = anomaly_results["combined_percentage"] / 100

    quality = run_full_quality_analysis(df, column_types, outlier_ratio=outlier_ratio)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Dataset Health", f"{quality.health_score}/100")
    col2.metric("Rows", f"{overview.row_count:,}")
    col3.metric("Missing Values", f"{overview.missing_percentage:.1f}%")
    col4.metric("Duplicate Rows", f"{quality.duplicate_percentage}%")

    st.markdown("---")
    left, right = st.columns(2)

    with left:
        st.subheader("Data Quality Highlights")
        issues = []
        if quality.constant_columns:
            issues.append(f"{len(quality.constant_columns)} constant column(s) found.")
        if quality.high_cardinality_columns:
            issues.append(f"{len(quality.high_cardinality_columns)} high-cardinality column(s) found.")
        if quality.dtype_issues:
            issues.append(f"{len(quality.dtype_issues)} possible data-type issue(s) found.")
        high_missing = quality.missing_summary[quality.missing_summary["Category"] == "High missingness"]
        if not high_missing.empty:
            issues.append(f"{len(high_missing)} column(s) with high missingness.")

        if issues:
            for issue in issues:
                st.write(f"- {issue}")
        else:
            st.write("No major data-quality issues were detected.")

        if anomaly_results is not None:
            st.write(
                f"- {anomaly_results['combined_count']} potential anomalies "
                f"({anomaly_results['combined_percentage']}% of rows)."
            )

    with right:
        st.subheader("Important Correlations")
        if len(column_types.numerical) >= 2:
            correlation_matrix = compute_correlation_matrix(df, column_types.numerical)
            relationships = find_significant_relationships(correlation_matrix)
            if not relationships.empty:
                st.dataframe(relationships.head(5), use_container_width=True, hide_index=True)
            else:
                st.write("No strong correlations were found.")
        else:
            st.write("Not enough numerical columns to analyze correlations.")

    st.markdown("---")
    st.subheader("Pattern Highlights")
    patterns = run_pattern_detection(
        df, column_types.categorical, column_types.numerical, column_types.datetime
    )
    if patterns:
        for finding in patterns[:5]:
            st.write(f"- {finding['title']}")
    else:
        st.write("No strong statistical patterns were detected.")

    st.markdown("---")
    st.subheader("Recommendations")
    recommendations = _build_recommendations(quality, column_types)
    for recommendation in recommendations:
        st.write(f"- {recommendation}")

    st.markdown("---")
    st.subheader("What You Can Do Next")
    clustering_ok, _ = is_clustering_suitable(df, column_types)
    ml_ok, _ = is_ml_feasible(df)
    next_steps = []
    if clustering_ok:
        next_steps.append("This dataset is suitable for clustering. Visit the Clustering page.")
    if ml_ok:
        next_steps.append("This dataset is large enough for machine learning. Visit the Machine Learning page.")
    next_steps.append("Visit the Reports page to download a full PDF investigation report.")
    for step in next_steps:
        st.write(f"- {step}")


def _build_recommendations(quality, column_types) -> list:
    recommendations = []

    high_missing = quality.missing_summary[quality.missing_summary["Category"] == "High missingness"]
    for column in high_missing["Column"].tolist():
        recommendations.append(
            f"Investigate the source of missing values in '{column}' before using it for modeling."
        )

    if quality.duplicate_count > 0:
        recommendations.append(
            f"Review the {quality.duplicate_count} duplicate row(s) and remove them if they are unintended."
        )

    for column in quality.constant_columns:
        recommendations.append(f"Consider dropping '{column}', which contains a single unique value.")

    for column in quality.identifier_columns:
        recommendations.append(f"Exclude '{column}' from predictive modeling since it behaves like an identifier.")

    if not recommendations:
        recommendations.append("No urgent data-quality actions are required based on the current analysis.")

    return recommendations
