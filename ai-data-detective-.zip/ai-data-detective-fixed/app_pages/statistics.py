"""Statistical Analysis page."""

import streamlit as st

from modules.data_loader import LoadedDataset
from modules.statistics import categorical_summary, column_deep_dive, numerical_summary


def render(dataset: LoadedDataset) -> None:
    st.header("Statistical Analysis")

    df = dataset.dataframe
    column_types = dataset.column_types

    if column_types.numerical:
        st.subheader("Numerical Columns")
        st.dataframe(numerical_summary(df, column_types.numerical), use_container_width=True)
    else:
        st.info("No numerical columns were found in this dataset.")

    if column_types.categorical:
        st.subheader("Categorical Columns")
        st.dataframe(categorical_summary(df, column_types.categorical), use_container_width=True)
    else:
        st.info("No categorical columns were found in this dataset.")

    st.markdown("---")
    st.subheader("Column Deep Dive")

    analyzable_columns = column_types.numerical + column_types.categorical
    if not analyzable_columns:
        st.info("No columns are available for a deeper look.")
        return

    selected_column = st.selectbox("Choose a column", analyzable_columns)
    result = column_deep_dive(df, selected_column)

    if result.get("empty"):
        st.warning("This column has no non-missing values to analyze.")
        return

    if result["type"] == "numerical":
        summary = result["summary"]
        cols = st.columns(4)
        cols[0].metric("Mean", summary["Mean"])
        cols[1].metric("Median", summary["Median"])
        cols[2].metric("Std Dev", summary["Std Dev"])
        cols[3].metric("Skewness", summary["Skewness"])

        with st.expander("Full statistics"):
            st.json(summary)

        p_value = result.get("normality_p_value")
        if p_value is not None:
            verdict = "looks approximately normal" if p_value > 0.05 else "does not look normally distributed"
            st.caption(
                f"Shapiro-Wilk normality test p-value: {p_value:.4f}. The distribution {verdict}."
            )
    else:
        st.dataframe(result["distribution"], use_container_width=True)
