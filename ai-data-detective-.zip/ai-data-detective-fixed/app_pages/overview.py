"""Dataset Overview page."""

import streamlit as st

from modules.data_loader import LoadedDataset
from modules.data_profiler import build_column_info_table, build_overview, get_row_sample


def render(dataset: LoadedDataset) -> None:
    st.header("Dataset Overview")

    df = dataset.dataframe
    overview = build_overview(df, dataset.column_types)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Rows", f"{overview.row_count:,}")
    col2.metric("Columns", overview.column_count)
    col3.metric("Memory Usage", overview.memory_usage)
    col4.metric("Missing Values", f"{overview.missing_percentage:.2f}%")

    col5, col6, col7, col8 = st.columns(4)
    col5.metric("Numerical Columns", overview.numerical_count)
    col6.metric("Categorical Columns", overview.categorical_count)
    col7.metric("Datetime Columns", overview.datetime_count)
    col8.metric("Duplicate Rows", f"{overview.duplicate_row_count} ({overview.duplicate_row_percentage:.1f}%)")

    if dataset.warnings:
        with st.expander("Notes about this upload"):
            for warning in dataset.warnings:
                st.write(f"- {warning}")

    st.markdown("---")
    st.subheader("Preview")

    view_mode = st.radio("Show", ["First rows", "Last rows", "Random rows"], horizontal=True)
    mode_map = {"First rows": "first", "Last rows": "last", "Random rows": "random"}
    sample = get_row_sample(df, mode_map[view_mode], n=15)
    st.dataframe(sample, use_container_width=True)

    st.markdown("---")
    st.subheader("Column Information")
    column_info = build_column_info_table(df)
    st.dataframe(column_info, use_container_width=True, height=420)
