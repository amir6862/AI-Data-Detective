"""Automatic Exploratory Data Analysis page."""

import streamlit as st

from modules.data_loader import LoadedDataset
from modules import visualization as viz


def render(dataset: LoadedDataset) -> None:
    st.header("Exploratory Data Analysis")

    df = dataset.dataframe
    column_types = dataset.column_types

    tabs = st.tabs(["Single Column", "Two Columns", "Categorical vs Numerical", "Time Series"])

    with tabs[0]:
        _render_single_column(df, column_types)

    with tabs[1]:
        _render_two_columns(df, column_types)

    with tabs[2]:
        _render_categorical_vs_numerical(df, column_types)

    with tabs[3]:
        _render_time_series(df, column_types)


def _render_single_column(df, column_types) -> None:
    if column_types.numerical:
        st.markdown("**Numerical column distribution**")
        column = st.selectbox("Numerical column", column_types.numerical, key="eda_num_single")
        chart_type = st.radio("Chart type", ["Histogram", "Box Plot", "Distribution"], horizontal=True)

        if chart_type == "Histogram":
            st.plotly_chart(viz.histogram(df, column), use_container_width=True)
        elif chart_type == "Box Plot":
            st.plotly_chart(viz.box_plot(df, column), use_container_width=True)
        else:
            st.plotly_chart(viz.density_plot(df, column), use_container_width=True)

    if column_types.categorical:
        st.markdown("**Categorical column frequency**")
        column = st.selectbox("Categorical column", column_types.categorical, key="eda_cat_single")
        st.plotly_chart(viz.bar_chart(df, column), use_container_width=True)


def _render_two_columns(df, column_types) -> None:
    if len(column_types.numerical) < 2:
        st.info("At least two numerical columns are needed for a scatter plot.")
        return

    col1, col2, col3 = st.columns(3)
    x_column = col1.selectbox("X axis", column_types.numerical, index=0)
    remaining = [c for c in column_types.numerical if c != x_column]
    y_column = col2.selectbox("Y axis", remaining, index=0)
    color_options = ["None"] + column_types.categorical
    color_choice = col3.selectbox("Color by", color_options)
    color_by = None if color_choice == "None" else color_choice

    st.plotly_chart(viz.scatter_plot(df, x_column, y_column, color_by), use_container_width=True)

    if len(column_types.numerical) >= 2:
        st.markdown("**Correlation heatmap**")
        correlation_matrix = df[column_types.numerical].corr()
        st.plotly_chart(viz.correlation_heatmap(correlation_matrix), use_container_width=True)


def _render_categorical_vs_numerical(df, column_types) -> None:
    if not column_types.categorical or not column_types.numerical:
        st.info("This view needs at least one categorical and one numerical column.")
        return

    col1, col2 = st.columns(2)
    categorical_column = col1.selectbox("Categorical column", column_types.categorical, key="eda_cvn_cat")
    numerical_column = col2.selectbox("Numerical column", column_types.numerical, key="eda_cvn_num")

    st.plotly_chart(
        viz.box_plot(df, numerical_column, group_by=categorical_column), use_container_width=True
    )
    st.plotly_chart(
        viz.grouped_bar_stats(df, categorical_column, numerical_column), use_container_width=True
    )


def _render_time_series(df, column_types) -> None:
    if not column_types.datetime or not column_types.numerical:
        st.info("This view needs at least one datetime column and one numerical column.")
        return

    col1, col2 = st.columns(2)
    date_column = col1.selectbox("Date column", column_types.datetime)
    value_column = col2.selectbox("Value column", column_types.numerical)

    st.plotly_chart(viz.time_series_plot(df, date_column, value_column), use_container_width=True)
