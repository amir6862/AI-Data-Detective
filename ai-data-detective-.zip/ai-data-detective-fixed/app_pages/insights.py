"""AI Insight Generator page."""

import streamlit as st

from config.config import OPENAI_API_KEY
from modules.anomaly_detection import run_automatic_anomaly_detection
from modules.correlation_analysis import (
    compute_correlation_matrix,
    explain_relationship,
    find_significant_relationships,
)
from modules.data_loader import LoadedDataset
from modules.data_quality import run_full_quality_analysis
from modules.insight_generator import generate_insights
from modules.pattern_detection import run_pattern_detection


def render(dataset: LoadedDataset) -> None:
    st.header("AI Insights")

    df = dataset.dataframe
    column_types = dataset.column_types

    if OPENAI_API_KEY:
        st.caption("An OpenAI API key is configured. Insights below are enhanced by the LLM.")
    else:
        st.caption(
            "No OpenAI API key is configured. Insights are generated using rule-based analysis, "
            "which is the default and fully functional mode."
        )

    context = _build_context(df, column_types)
    result = generate_insights(context)

    for insight in result["insights"]:
        st.write(f"- {insight}")

    st.caption(f"Insight source: {result['source'].replace('_', ' ')}.")


def _build_context(df, column_types) -> dict:
    quality = run_full_quality_analysis(df, column_types)

    high_missing = quality.missing_summary[quality.missing_summary["Category"] == "High missingness"]

    top_correlations = []
    if len(column_types.numerical) >= 2:
        correlation_matrix = compute_correlation_matrix(df, column_types.numerical)
        relationships = find_significant_relationships(correlation_matrix)
        top_correlations = [explain_relationship(row) for _, row in relationships.head(3).iterrows()]

    anomaly_notes = []
    if column_types.numerical:
        anomaly_results = run_automatic_anomaly_detection(df, column_types.numerical)
        if anomaly_results["combined_count"] > 0:
            anomaly_notes.append(
                f"{anomaly_results['combined_count']} potential anomalies were found, representing "
                f"{anomaly_results['combined_percentage']}% of rows."
            )

    patterns = run_pattern_detection(
        df, column_types.categorical, column_types.numerical, column_types.datetime
    )

    return {
        "health_score": quality.health_score,
        "quality_findings": {
            "high_missing_columns": high_missing["Column"].tolist(),
            "duplicate_percentage": quality.duplicate_percentage,
        },
        "top_correlations": top_correlations,
        "anomaly_notes": anomaly_notes,
        "pattern_findings": patterns,
    }
