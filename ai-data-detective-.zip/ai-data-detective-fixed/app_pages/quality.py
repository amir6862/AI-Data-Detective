"""Data Quality Detective page."""

import streamlit as st

from modules.anomaly_detection import run_automatic_anomaly_detection
from modules.data_loader import LoadedDataset
from modules.data_quality import run_full_quality_analysis


def render(dataset: LoadedDataset) -> None:
    st.header("Data Quality Detective")

    df = dataset.dataframe
    column_types = dataset.column_types

    outlier_ratio = 0.0
    if column_types.numerical:
        anomaly_summary = run_automatic_anomaly_detection(df, column_types.numerical)
        outlier_ratio = anomaly_summary["combined_percentage"] / 100

    quality = run_full_quality_analysis(df, column_types, outlier_ratio=outlier_ratio)

    score_col, breakdown_col = st.columns([1, 2])
    with score_col:
        st.metric("Dataset Health Score", f"{quality.health_score} / 100", label_visibility="visible")
        st.progress(quality.health_score / 100)

    with breakdown_col:
        st.write("Score breakdown (points deducted per category):")
        st.dataframe(
            {"Category": list(quality.health_breakdown.keys()), "Impact": list(quality.health_breakdown.values())},
            use_container_width=True,
            hide_index=True,
        )

    st.markdown("---")
    st.subheader("Missing Values")
    st.dataframe(quality.missing_summary, use_container_width=True)

    st.markdown("---")
    st.subheader("Duplicate Records")
    dup_col1, dup_col2 = st.columns(2)
    dup_col1.metric("Duplicate Rows", quality.duplicate_count)
    dup_col2.metric("Duplicate Percentage", f"{quality.duplicate_percentage}%")
    if not quality.duplicate_examples.empty:
        with st.expander("View duplicate examples"):
            st.dataframe(quality.duplicate_examples, use_container_width=True)

    st.markdown("---")
    st.subheader("Constant and Near-Constant Columns")
    if quality.constant_columns:
        st.write("Columns with a single unique value:")
        st.write(", ".join(quality.constant_columns))
    else:
        st.write("No fully constant columns were found.")

    if quality.near_constant_columns:
        st.write("Columns dominated by one value (98% or more):")
        st.dataframe(
            {
                "Column": list(quality.near_constant_columns.keys()),
                "Dominant Value Share (%)": list(quality.near_constant_columns.values()),
            },
            use_container_width=True,
            hide_index=True,
        )

    st.markdown("---")
    st.subheader("High Cardinality and Identifier Columns")
    col_a, col_b = st.columns(2)
    with col_a:
        st.write("High-cardinality columns:")
        if quality.high_cardinality_columns:
            st.dataframe(quality.high_cardinality_columns, use_container_width=True, hide_index=True)
        else:
            st.write("None detected.")
    with col_b:
        st.write("Potential identifier columns:")
        if quality.identifier_columns:
            for column in quality.identifier_columns:
                st.write(f"- {column}: likely an identifier and not useful as a predictive feature.")
        else:
            st.write("None detected.")

    st.markdown("---")
    st.subheader("Data Type Issues")
    if quality.dtype_issues:
        st.dataframe(quality.dtype_issues, use_container_width=True)
    else:
        st.write("No obvious data-type mismatches were found.")

    st.markdown("---")
    st.subheader("Invalid Value Findings")
    if quality.invalid_value_findings:
        st.dataframe(quality.invalid_value_findings, use_container_width=True)
    else:
        st.write("No implausible values were detected based on column-name heuristics.")
