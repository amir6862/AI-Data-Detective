"""Machine Learning page."""

import streamlit as st

from models import classification as classification_models
from models import regression as regression_models
from modules import visualization as viz
from modules.data_loader import LoadedDataset
from modules.prediction import (
    build_comparison_table,
    compute_permutation_importance,
    detect_task_type,
    is_ml_feasible,
    prepare_ml_data,
    run_classification_comparison,
    run_regression_comparison,
    select_candidate_features,
)


def render(dataset: LoadedDataset) -> None:
    st.header("Machine Learning")

    df = dataset.dataframe
    column_types = dataset.column_types

    feasible, reason = is_ml_feasible(df)
    if not feasible:
        st.info(f"Machine learning is not available for this dataset: {reason}")
        return

    target_column = st.selectbox("Select a target column", df.columns.tolist())

    if target_column in column_types.identifier_like:
        st.warning(
            "This column looks like an identifier. Models trained on it are unlikely to be meaningful."
        )

    task_type = detect_task_type(df[target_column])
    st.write(f"Detected task type: **{task_type.title()}**")

    candidate_features = select_candidate_features(df, target_column, column_types)
    selected_features = st.multiselect(
        "Feature columns", candidate_features, default=candidate_features
    )

    if not selected_features:
        st.warning("Select at least one feature column to train models.")
        return

    if st.button("Train and compare models", type="primary"):
        with st.spinner("Training models..."):
            prepared = prepare_ml_data(df, target_column, selected_features, task_type)

            if task_type == "classification":
                imbalance = classification_models.detect_class_imbalance(prepared.y_train)
                if imbalance["is_imbalanced"]:
                    st.warning(
                        f"The target classes are imbalanced (majority class share: "
                        f"{imbalance['majority_share'] * 100:.1f}%). Accuracy alone may be misleading; "
                        "review precision, recall, and F1 score as well."
                    )
                results = run_classification_comparison(prepared)
            else:
                results = run_regression_comparison(prepared)

            st.session_state["ml_results_cache"] = {
                "results": results,
                "prepared": prepared,
                "task_type": task_type,
                "target_column": target_column,
            }

    cache = st.session_state.get("ml_results_cache", {})
    if not cache or cache.get("target_column") != target_column:
        st.info("Train models to see comparison results.")
        return

    _render_results(cache)


def _render_results(cache: dict) -> None:
    results = cache["results"]
    prepared = cache["prepared"]
    task_type = cache["task_type"]

    comparison_table = build_comparison_table(results, task_type)
    if comparison_table.empty:
        st.error("All models failed to train on this data. Try different features or target.")
        return

    st.markdown("---")
    st.subheader("Model Comparison")
    st.dataframe(comparison_table, use_container_width=True)

    model_names = [name for name in results if "error" not in results[name]]
    selected_model_name = st.selectbox("Inspect a model in detail", model_names)
    selected_result = results[selected_model_name]

    st.markdown("---")
    st.subheader(f"Details: {selected_model_name}")
    st.json(selected_result["metrics"])

    if task_type == "classification":
        st.plotly_chart(
            viz.confusion_matrix_heatmap(selected_result["confusion_matrix"], selected_result["classes"]),
            use_container_width=True,
        )
        importer = classification_models
    else:
        st.plotly_chart(
            viz.actual_vs_predicted(prepared.y_test, selected_result["predictions"]),
            use_container_width=True,
        )
        importer = regression_models

    st.markdown("---")
    st.subheader("Feature Importance")
    importance_df = importer.get_feature_importance(selected_result["model"], prepared.feature_names)

    if importance_df.empty:
        st.write("This model does not expose built-in feature importance. Computing permutation importance instead.")
        importance_df = compute_permutation_importance(selected_result["model"], prepared)

    if not importance_df.empty:
        st.plotly_chart(viz.feature_importance_bar(importance_df), use_container_width=True)
        st.caption("Feature importance reflects predictive usefulness, not necessarily causality.")
