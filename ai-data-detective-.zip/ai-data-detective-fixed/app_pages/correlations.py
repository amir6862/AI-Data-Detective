"""Correlation Detective page."""

import streamlit as st

from modules import visualization as viz
from modules.correlation_analysis import (
    choose_correlation_method,
    compute_correlation_matrix,
    explain_relationship,
    find_significant_relationships,
)
from modules.data_loader import LoadedDataset


def render(dataset: LoadedDataset) -> None:
    st.header("Correlation Detective")

    df = dataset.dataframe
    numerical_columns = dataset.column_types.numerical

    if len(numerical_columns) < 2:
        st.info("At least two numerical columns are required to analyze correlations.")
        return

    suggested_method = choose_correlation_method(df, numerical_columns)
    method = st.radio(
        "Correlation method",
        ["pearson", "spearman"],
        index=0 if suggested_method == "pearson" else 1,
        horizontal=True,
        help="Pearson measures linear relationships. Spearman measures monotonic rank relationships "
        "and is more robust to skewed data.",
    )

    threshold = st.slider("Strong relationship threshold", 0.5, 0.95, 0.7, 0.05)

    correlation_matrix = compute_correlation_matrix(df, numerical_columns, method=method)
    st.plotly_chart(viz.correlation_heatmap(correlation_matrix), use_container_width=True)

    st.markdown("---")
    st.subheader("Significant Relationships")

    relationships = find_significant_relationships(correlation_matrix, threshold=threshold)

    if relationships.empty:
        st.write("No relationships met the selected threshold.")
        return

    st.dataframe(relationships, use_container_width=True)

    st.markdown("**Explanations**")
    for _, row in relationships.head(10).iterrows():
        st.write(f"- {explain_relationship(row)}")

    st.caption("Correlation measures statistical association only and does not imply causation.")
