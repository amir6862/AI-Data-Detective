"""Clustering page."""

import streamlit as st

from modules import visualization as viz
from modules.clustering import is_clustering_suitable, run_dbscan_pipeline, run_kmeans_pipeline
from modules.data_loader import LoadedDataset


def render(dataset: LoadedDataset) -> None:
    st.header("Clustering")

    df = dataset.dataframe
    column_types = dataset.column_types

    suitable, reason = is_clustering_suitable(df, column_types)
    if not suitable:
        st.info(f"Clustering is not available for this dataset: {reason}")
        return

    usable_columns = [c for c in column_types.numerical if c not in column_types.identifier_like]
    st.write(
        f"Using {len(usable_columns)} non-identifier numerical column(s) as clustering features: "
        f"{', '.join(usable_columns)}."
    )

    selected_features = st.multiselect("Features to use", usable_columns, default=usable_columns)
    if len(selected_features) < 2:
        st.warning("Select at least two features to run clustering.")
        return

    algorithm = st.radio("Algorithm", ["K-Means", "DBSCAN"], horizontal=True)

    if algorithm == "K-Means":
        _render_kmeans(df, selected_features)
    else:
        _render_dbscan(df, selected_features)


def _render_kmeans(df, features) -> None:
    auto_k = st.checkbox("Automatically choose K using silhouette score", value=True)
    manual_k = None
    if not auto_k:
        manual_k = st.slider("Number of clusters (K)", 2, 10, 3)

    result = run_kmeans_pipeline(df, features, n_clusters=manual_k)

    st.plotly_chart(viz.elbow_plot(result["k_values"], result["inertias"]), use_container_width=True)

    st.write(f"Selected K = {result['k']}")
    st.write("Cluster sizes:")
    st.dataframe(
        {"Cluster": list(result["cluster_sizes"].keys()), "Size": list(result["cluster_sizes"].values())},
        use_container_width=True,
        hide_index=True,
    )

    _render_cluster_scatter_and_profile(df, features, result)


def _render_dbscan(df, features) -> None:
    min_samples = st.slider("Minimum samples", 3, 20, 5)
    result = run_dbscan_pipeline(df, features, min_samples=min_samples)

    st.write(f"Estimated epsilon: {result['eps']}")
    st.write(f"Noise points: {result['noise_count']} ({result['noise_percentage']}%)")

    st.write("Cluster sizes (label -1 means noise):")
    st.dataframe(
        {"Cluster": list(result["cluster_sizes"].keys()), "Size": list(result["cluster_sizes"].values())},
        use_container_width=True,
        hide_index=True,
    )

    _render_cluster_scatter_and_profile(df, features, result)


def _render_cluster_scatter_and_profile(df, features, result) -> None:
    if len(features) >= 2:
        plot_df = df.loc[result["valid_index"]]
        st.plotly_chart(
            viz.cluster_scatter(plot_df, features[0], features[1], result["labels"]),
            use_container_width=True,
        )

    st.markdown("**Cluster Characteristics**")
    st.dataframe(result["profile"], use_container_width=True)
