"""Pattern Detective page."""

import streamlit as st

from modules.data_loader import LoadedDataset
from modules.pattern_detection import run_pattern_detection


def render(dataset: LoadedDataset) -> None:
    st.header("Pattern Detective")

    df = dataset.dataframe
    column_types = dataset.column_types

    findings = run_pattern_detection(
        df, column_types.categorical, column_types.numerical, column_types.datetime
    )

    if not findings:
        st.info(
            "No strong statistical patterns were detected with the current thresholds. "
            "This can happen with small or highly uniform datasets."
        )
        return

    st.write(f"{len(findings)} pattern(s) detected.")

    finding_types = sorted({f["type"] for f in findings})
    selected_types = st.multiselect("Filter by finding type", finding_types, default=finding_types)

    for finding in findings:
        if finding["type"] not in selected_types:
            continue
        with st.container(border=True):
            st.markdown(f"**{finding['title']}**")
            st.write(finding["explanation"])
            st.caption(f"Supporting statistic: {finding['statistic']}")
