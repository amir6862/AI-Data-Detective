"""Anomaly Detective page."""

import streamlit as st

from modules.anomaly_detection import detect_iqr_outliers, detect_zscore_outliers, run_automatic_anomaly_detection
from modules.data_loader import LoadedDataset


def render(dataset: LoadedDataset) -> None:
    st.header("Anomaly Detective")

    df = dataset.dataframe
    numerical_columns = dataset.column_types.numerical

    if not numerical_columns:
        st.info("No numerical columns are available for anomaly detection.")
        return

    results = run_automatic_anomaly_detection(df, numerical_columns)

    col1, col2 = st.columns(2)
    col1.metric("Potential Anomalies", results["combined_count"])
    col2.metric("Percentage of Rows", f"{results['combined_percentage']}%")

    st.caption(
        "These are potential anomalies or unusual observations, not confirmed data errors. "
        "Review them in context before taking action."
    )

    st.markdown("---")
    st.subheader("Per-Column IQR Analysis")
    column = st.selectbox("Column", numerical_columns)
    method = st.radio("Method", ["IQR", "Z-Score"], horizontal=True)

    result = detect_iqr_outliers(df, column) if method == "IQR" else detect_zscore_outliers(df, column)

    m1, m2 = st.columns(2)
    m1.metric("Anomalies Found", result.anomaly_count)
    m2.metric("Percentage", f"{result.anomaly_percentage}%")

    if not result.anomalies.empty:
        st.dataframe(result.anomalies.head(50), use_container_width=True)
        csv_bytes = result.anomalies.to_csv(index=False).encode("utf-8")
        st.download_button(
            "Download anomalies as CSV",
            data=csv_bytes,
            file_name=f"anomalies_{column}.csv",
            mime="text/csv",
        )
    else:
        st.write("No anomalies detected for this column with the selected method.")

    if results["multivariate"] is not None:
        st.markdown("---")
        st.subheader("Multivariate Analysis (Isolation Forest)")
        multivariate = results["multivariate"]
        st.write(
            f"Using columns: {', '.join(multivariate.contributing_columns)}. "
            f"Found {multivariate.anomaly_count} unusual observations "
            f"({multivariate.anomaly_percentage}% of rows)."
        )
        if not multivariate.anomalies.empty:
            st.dataframe(multivariate.anomalies.head(50), use_container_width=True)
            csv_bytes = multivariate.anomalies.to_csv(index=False).encode("utf-8")
            st.download_button(
                "Download multivariate anomalies as CSV",
                data=csv_bytes,
                file_name="anomalies_multivariate.csv",
                mime="text/csv",
            )
