"""Report Generation and Data Export page."""

import streamlit as st

from modules.anomaly_detection import run_automatic_anomaly_detection
from modules.correlation_analysis import compute_correlation_matrix, find_significant_relationships
from modules.data_loader import LoadedDataset
from modules.data_profiler import build_overview
from modules.data_quality import run_full_quality_analysis
from modules.insight_generator import generate_insights
from modules.pattern_detection import run_pattern_detection
from modules.report_generator import generate_report
from modules.statistics import numerical_summary


def render(dataset: LoadedDataset) -> None:
    st.header("Reports and Data Export")

    df = dataset.dataframe
    column_types = dataset.column_types

    st.subheader("Downloadable Data")
    export_col1, export_col2, export_col3 = st.columns(3)

    with export_col1:
        st.download_button(
            "Download dataset (as loaded)",
            data=df.to_csv(index=False).encode("utf-8"),
            file_name="dataset_as_loaded.csv",
            mime="text/csv",
        )

    quality = run_full_quality_analysis(df, column_types)
    with export_col2:
        st.download_button(
            "Download missing-value summary",
            data=quality.missing_summary.to_csv(index=False).encode("utf-8"),
            file_name="missing_value_summary.csv",
            mime="text/csv",
        )

    numerical_stats = numerical_summary(df, column_types.numerical) if column_types.numerical else None
    if numerical_stats is not None and not numerical_stats.empty:
        with export_col3:
            st.download_button(
                "Download statistical summary",
                data=numerical_stats.to_csv(index=False).encode("utf-8"),
                file_name="statistical_summary.csv",
                mime="text/csv",
            )

    correlations = None
    if len(column_types.numerical) >= 2:
        correlation_matrix = compute_correlation_matrix(df, column_types.numerical)
        correlations = find_significant_relationships(correlation_matrix)
        if not correlations.empty:
            st.download_button(
                "Download correlation findings",
                data=correlations.to_csv(index=False).encode("utf-8"),
                file_name="correlation_findings.csv",
                mime="text/csv",
            )

    anomaly_summary = None
    if column_types.numerical:
        anomaly_summary = run_automatic_anomaly_detection(df, column_types.numerical)
        if anomaly_summary["combined_indices"]:
            anomaly_rows = df.loc[list(anomaly_summary["combined_indices"])]
            st.download_button(
                "Download anomaly records",
                data=anomaly_rows.to_csv(index=False).encode("utf-8"),
                file_name="anomaly_records.csv",
                mime="text/csv",
            )

    patterns = run_pattern_detection(
        df, column_types.categorical, column_types.numerical, column_types.datetime
    )

    ml_cache = st.session_state.get("ml_results_cache", {})
    ml_comparison = None
    feature_importance = None
    if ml_cache:
        from modules.prediction import build_comparison_table

        ml_comparison = build_comparison_table(ml_cache["results"], ml_cache["task_type"])
        if not ml_comparison.empty:
            st.download_button(
                "Download model comparison",
                data=ml_comparison.to_csv(index=False).encode("utf-8"),
                file_name="model_comparison.csv",
                mime="text/csv",
            )

    st.markdown("---")
    st.subheader("Final Investigation Report")
    st.write(
        "Generates a PDF summarizing the dataset overview, data quality, statistics, "
        "correlations, anomalies, patterns, clustering, machine learning results, and insights."
    )

    if st.button("Generate PDF report", type="primary"):
        with st.spinner("Building report..."):
            insight_context = {
                "health_score": quality.health_score,
                "quality_findings": {
                    "duplicate_percentage": quality.duplicate_percentage,
                    "high_missing_columns": quality.missing_summary[
                        quality.missing_summary["Category"] == "High missingness"
                    ]["Column"].tolist(),
                },
                "top_correlations": [],
                "anomaly_notes": [],
                "pattern_findings": patterns,
            }
            insights = generate_insights(insight_context)

            clustering_cache = st.session_state.get("clustering_cache", {})

            report_context = {
                "filename": dataset.filename,
                "overview": build_overview(df, column_types),
                "quality": quality,
                "numerical_stats": numerical_stats,
                "correlations": correlations,
                "anomaly_summary": anomaly_summary,
                "patterns": patterns,
                "clustering": clustering_cache.get("result"),
                "ml_comparison": ml_comparison,
                "feature_importance": feature_importance,
                "insights": insights["insights"],
            }

            pdf_bytes = generate_report(report_context)

        st.success("Report generated.")
        st.download_button(
            "Download PDF report",
            data=pdf_bytes,
            file_name="ai_data_detective_report.pdf",
            mime="application/pdf",
        )
