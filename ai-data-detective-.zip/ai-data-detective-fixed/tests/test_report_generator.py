from modules.data_loader import load_dataset
from modules.data_profiler import build_overview
from modules.data_quality import run_full_quality_analysis
from modules.report_generator import generate_report
from modules.statistics import numerical_summary


def test_report_generation_produces_pdf_bytes(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    overview = build_overview(loaded.dataframe, loaded.column_types)
    quality = run_full_quality_analysis(loaded.dataframe, loaded.column_types)
    stats = numerical_summary(loaded.dataframe, loaded.column_types.numerical)

    context = {
        "filename": "sample.csv",
        "overview": overview,
        "quality": quality,
        "numerical_stats": stats,
        "correlations": None,
        "anomaly_summary": None,
        "patterns": [],
        "clustering": None,
        "ml_comparison": None,
        "feature_importance": None,
        "insights": ["Test insight for report generation."],
    }

    pdf_bytes = generate_report(context)

    assert isinstance(pdf_bytes, bytes)
    assert pdf_bytes.startswith(b"%PDF")
    assert len(pdf_bytes) > 500


def test_report_generation_handles_minimal_context():
    context = {"filename": "empty.csv"}
    pdf_bytes = generate_report(context)
    assert pdf_bytes.startswith(b"%PDF")
