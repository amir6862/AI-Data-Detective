from modules.insight_generator import build_rule_based_insights, generate_insights


def test_rule_based_insights_include_health_score():
    context = {"health_score": 92, "quality_findings": {}}
    insights = build_rule_based_insights(context)
    assert any("92" in insight for insight in insights)


def test_rule_based_insights_fallback_message_when_empty():
    insights = build_rule_based_insights({})
    assert len(insights) == 1


def test_generate_insights_uses_rule_based_without_api_key(monkeypatch):
    monkeypatch.setattr("modules.insight_generator.OPENAI_API_KEY", "")
    result = generate_insights({"health_score": 80})
    assert result["source"] == "rule_based"
    assert isinstance(result["insights"], list)
