import numpy as np
import pandas as pd

from modules.pattern_detection import (
    detect_concentration,
    detect_group_differences,
    detect_time_trend,
)


def test_detect_group_differences_finds_high_performer():
    rng = np.random.default_rng(5)
    df = pd.DataFrame(
        {
            "group": ["A"] * 50 + ["B"] * 50,
            "value": list(rng.normal(10, 1, 50)) + list(rng.normal(50, 1, 50)),
        }
    )

    findings = detect_group_differences(df, "group", "value")
    titles = [f["title"] for f in findings]
    assert any("B" in title for title in titles)


def test_detect_time_trend_finds_increasing_trend():
    dates = pd.date_range("2023-01-01", periods=100, freq="D")
    values = np.arange(100) + np.random.default_rng(6).normal(0, 1, 100)
    df = pd.DataFrame({"date": dates, "value": values})

    findings = detect_time_trend(df, "date", "value")
    assert len(findings) == 1
    assert "increasing" in findings[0]["title"]


def test_detect_time_trend_no_trend_for_noise():
    dates = pd.date_range("2023-01-01", periods=100, freq="D")
    values = np.random.default_rng(7).normal(0, 1, 100)
    df = pd.DataFrame({"date": dates, "value": values})

    findings = detect_time_trend(df, "date", "value")
    assert findings == []


def test_detect_concentration_flags_dominant_value():
    df = pd.DataFrame({"category": ["A"] * 80 + ["B"] * 20})
    findings = detect_concentration(df, "category", threshold=0.6)
    assert len(findings) == 1
    assert "A" in findings[0]["title"]


def test_detect_concentration_no_flag_when_balanced():
    df = pd.DataFrame({"category": ["A"] * 50 + ["B"] * 50})
    findings = detect_concentration(df, "category", threshold=0.6)
    assert findings == []
