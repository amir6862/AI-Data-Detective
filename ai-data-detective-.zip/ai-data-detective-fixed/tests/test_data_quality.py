from modules.data_loader import load_dataset
from modules.data_quality import (
    analyze_duplicates,
    analyze_missing_values,
    calculate_health_score,
    find_constant_columns,
    find_dtype_issues,
    find_invalid_values,
    run_full_quality_analysis,
)


def test_missing_value_detection(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    summary = analyze_missing_values(loaded.dataframe)

    income_row = summary[summary["Column"] == "Income"].iloc[0]
    assert income_row["Missing Count"] >= 10
    assert income_row["Category"] in {"Low missingness", "Moderate missingness", "High missingness"}


def test_duplicate_detection(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    duplicate_count, duplicate_pct, examples = analyze_duplicates(loaded.dataframe)

    assert duplicate_count >= 3
    assert duplicate_pct > 0
    assert not examples.empty


def test_constant_column_detection():
    import pandas as pd

    df = pd.DataFrame({"a": [1, 1, 1, 1], "b": [1, 2, 3, 4]})
    constants = find_constant_columns(df)
    assert constants == ["a"]


def test_invalid_age_values(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    findings = find_invalid_values(loaded.dataframe, loaded.column_types)

    age_findings = [f for f in findings if f["Column"] == "Age"]
    assert len(age_findings) == 1
    assert age_findings[0]["Count"] >= 1


def test_dtype_issue_detection():
    import pandas as pd

    df = pd.DataFrame({"salary": ["50000", "62000", "71000", "48000"]})
    findings = find_dtype_issues(df)
    assert len(findings) == 1
    assert findings[0]["Column"] == "salary"


def test_health_score_is_reproducible(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    report_a = run_full_quality_analysis(loaded.dataframe, loaded.column_types)
    report_b = run_full_quality_analysis(loaded.dataframe, loaded.column_types)

    assert report_a.health_score == report_b.health_score
    assert 0 <= report_a.health_score <= 100


def test_health_score_penalizes_problems():
    import pandas as pd

    good_summary = pd.DataFrame({"Column": ["a"], "Missing %": [0.0]})
    bad_summary = pd.DataFrame({"Column": ["a"], "Missing %": [40.0]})

    good_score, _ = calculate_health_score(pd.DataFrame(), good_summary, 0.0, [], [], [], 0.0)
    bad_score, _ = calculate_health_score(pd.DataFrame(), bad_summary, 20.0, ["x"], ["y"], ["z"], 0.2)

    assert good_score > bad_score
