import numpy as np
import pandas as pd

from modules.correlation_analysis import (
    compute_correlation_matrix,
    explain_relationship,
    find_significant_relationships,
)


def test_strong_positive_correlation_detected():
    rng = np.random.default_rng(3)
    x = rng.normal(0, 1, 200)
    y = x * 2 + rng.normal(0, 0.05, 200)
    df = pd.DataFrame({"x": x, "y": y})

    matrix = compute_correlation_matrix(df, ["x", "y"])
    relationships = find_significant_relationships(matrix, threshold=0.7)

    assert len(relationships) == 1
    assert relationships.iloc[0]["Strength"] == "Strong"
    assert relationships.iloc[0]["Direction"] == "Positive"


def test_no_relationship_for_independent_columns():
    rng = np.random.default_rng(4)
    df = pd.DataFrame({"x": rng.normal(0, 1, 300), "y": rng.normal(0, 1, 300)})

    matrix = compute_correlation_matrix(df, ["x", "y"])
    relationships = find_significant_relationships(matrix, threshold=0.7)

    assert relationships.empty


def test_explain_relationship_mentions_columns():
    row = pd.Series(
        {"Column A": "Income", "Column B": "Spending", "Correlation": 0.85,
         "Strength": "Strong", "Direction": "Positive"}
    )
    explanation = explain_relationship(row)
    assert "Income" in explanation
    assert "Spending" in explanation
    assert "causation" not in explanation or "does not" in explanation


def test_empty_matrix_returns_empty_dataframe():
    result = find_significant_relationships(pd.DataFrame())
    assert result.empty
