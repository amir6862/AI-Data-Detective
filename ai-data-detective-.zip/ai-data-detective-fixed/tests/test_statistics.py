import pandas as pd

from modules.data_loader import load_dataset
from modules.statistics import categorical_summary, column_deep_dive, numerical_summary


def test_numerical_summary_columns(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    summary = numerical_summary(loaded.dataframe, loaded.column_types.numerical)

    expected_columns = {
        "Column", "Count", "Mean", "Median", "Mode", "Std Dev", "Variance",
        "Min", "Max", "Range", "Q1", "Q3", "IQR", "Skewness", "Kurtosis",
    }
    assert expected_columns.issubset(set(summary.columns))
    assert len(summary) == len(loaded.column_types.numerical)


def test_numerical_summary_values_are_sane():
    df = pd.DataFrame({"x": [1, 2, 3, 4, 5]})
    summary = numerical_summary(df, ["x"])
    row = summary.iloc[0]

    assert row["Mean"] == 3
    assert row["Min"] == 1
    assert row["Max"] == 5
    assert row["Range"] == 4


def test_categorical_summary(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    summary = categorical_summary(loaded.dataframe, loaded.column_types.categorical)

    assert "Unique Values" in summary.columns
    assert (summary["Percentage"] <= 100).all()


def test_column_deep_dive_numerical(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    result = column_deep_dive(loaded.dataframe, "Income")
    assert result["type"] == "numerical"
    assert "summary" in result


def test_column_deep_dive_categorical(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    result = column_deep_dive(loaded.dataframe, "Gender")
    assert result["type"] == "categorical"
    assert not result["distribution"].empty
