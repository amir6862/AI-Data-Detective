import pandas as pd
import pytest

from modules.data_loader import load_dataset
from utils.validators import DatasetValidationError


def test_load_valid_csv(csv_bytes):
    result = load_dataset(csv_bytes, "sample.csv")

    assert result.dataframe.shape[0] > 0
    assert result.dataframe.shape[1] > 0
    assert "Age" in result.dataframe.columns


def test_load_detects_column_types(csv_bytes):
    result = load_dataset(csv_bytes, "sample.csv")

    assert "Income" in result.column_types.numerical
    assert "Gender" in result.column_types.categorical
    assert "SignupDate" in result.column_types.datetime


def test_load_empty_csv_raises():
    empty_bytes = b""
    with pytest.raises(DatasetValidationError):
        load_dataset(empty_bytes, "empty.csv")


def test_load_unsupported_extension_raises(csv_bytes):
    with pytest.raises(DatasetValidationError):
        load_dataset(csv_bytes, "sample.pdf")


def test_load_csv_with_duplicate_headers_is_auto_disambiguated():
    # pandas itself renames repeated headers (a, a -> a, a.1) while parsing,
    # so by the time our validator sees the columns they are already unique.
    raw = b"a,a,b\n1,2,3\n4,5,6\n"
    result = load_dataset(raw, "dup_columns.csv")
    assert len(result.dataframe.columns) == len(set(result.dataframe.columns))


def test_load_semicolon_delimited_csv():
    raw = b"a;b;c\n1;2;3\n4;5;6\n7;8;9\n"
    result = load_dataset(raw, "semicolon.csv")
    assert result.dataframe.shape == (3, 3)
