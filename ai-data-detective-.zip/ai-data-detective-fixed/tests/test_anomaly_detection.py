import numpy as np
import pandas as pd

from modules.anomaly_detection import (
    detect_iqr_outliers,
    detect_isolation_forest_outliers,
    detect_zscore_outliers,
    run_automatic_anomaly_detection,
)


def test_iqr_detects_obvious_outlier():
    df = pd.DataFrame({"value": [10, 11, 12, 13, 12, 11, 10, 500]})
    result = detect_iqr_outliers(df, "value")

    assert result.anomaly_count == 1
    assert 7 in result.anomaly_indices


def test_zscore_detects_obvious_outlier():
    values = list(np.random.default_rng(1).normal(50, 5, 100))
    values.append(500)
    df = pd.DataFrame({"value": values})

    result = detect_zscore_outliers(df, "value")
    assert result.anomaly_count >= 1
    assert (len(values) - 1) in result.anomaly_indices


def test_zscore_handles_zero_std():
    df = pd.DataFrame({"value": [5, 5, 5, 5]})
    result = detect_zscore_outliers(df, "value")
    assert result.anomaly_count == 0


def test_isolation_forest_runs_on_multivariate_data():
    rng = np.random.default_rng(2)
    normal_points = rng.normal(0, 1, (100, 2))
    outliers = rng.normal(20, 1, (5, 2))
    data = np.vstack([normal_points, outliers])
    df = pd.DataFrame(data, columns=["a", "b"])

    result = detect_isolation_forest_outliers(df, ["a", "b"], contamination=0.05)
    assert result.anomaly_count > 0


def test_automatic_detection_combines_methods(csv_bytes):
    from modules.data_loader import load_dataset

    loaded = load_dataset(csv_bytes, "sample.csv")
    results = run_automatic_anomaly_detection(loaded.dataframe, loaded.column_types.numerical)

    assert "combined_count" in results
    assert results["combined_percentage"] >= 0
