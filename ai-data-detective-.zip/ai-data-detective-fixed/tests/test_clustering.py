import numpy as np
import pandas as pd

from modules.clustering import is_clustering_suitable, run_dbscan_pipeline, run_kmeans_pipeline
from utils.helpers import ColumnTypes


def _make_blob_dataframe():
    rng = np.random.default_rng(8)
    blob_a = rng.normal(0, 0.5, (50, 2))
    blob_b = rng.normal(10, 0.5, (50, 2))
    data = np.vstack([blob_a, blob_b])
    return pd.DataFrame(data, columns=["feature_1", "feature_2"])


def test_clustering_suitability_rejects_small_data():
    df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
    column_types = ColumnTypes(numerical=["a", "b"])
    suitable, reason = is_clustering_suitable(df, column_types)
    assert not suitable
    assert "rows" in reason


def test_clustering_suitability_rejects_single_feature():
    df = pd.DataFrame({"a": range(50)})
    column_types = ColumnTypes(numerical=["a"])
    suitable, reason = is_clustering_suitable(df, column_types)
    assert not suitable


def test_kmeans_finds_two_clusters():
    df = _make_blob_dataframe()
    result = run_kmeans_pipeline(df, ["feature_1", "feature_2"], n_clusters=2)

    assert result["k"] == 2
    assert len(result["cluster_sizes"]) == 2
    assert not result["profile"].empty


def test_dbscan_separates_blobs():
    df = _make_blob_dataframe()
    result = run_dbscan_pipeline(df, ["feature_1", "feature_2"], min_samples=5)

    non_noise_clusters = [c for c in result["cluster_sizes"] if c != -1]
    assert len(non_noise_clusters) >= 1
