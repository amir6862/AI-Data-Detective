import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def sample_dataframe() -> pd.DataFrame:
    rng = np.random.default_rng(0)
    n = 200

    df = pd.DataFrame(
        {
            "CustomerID": range(1, n + 1),
            "Age": rng.integers(18, 70, n).astype(float),
            "Gender": rng.choice(["Male", "Female"], n),
            "Region": rng.choice(["North", "South", "East", "West"], n),
            "Income": rng.normal(50000, 15000, n).round(2),
            "Purchases": rng.poisson(5, n),
            "SignupDate": pd.date_range("2022-01-01", periods=n, freq="D"),
            "Segment": rng.choice(["A", "B", "C"], n),
        }
    )

    df.loc[5:15, "Income"] = np.nan
    df.loc[0, "Age"] = -5
    df = pd.concat([df, df.iloc[0:3]], ignore_index=True)
    return df


@pytest.fixture
def csv_bytes(sample_dataframe: pd.DataFrame) -> bytes:
    return sample_dataframe.to_csv(index=False).encode("utf-8")
