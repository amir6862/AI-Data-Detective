import numpy as np
import pandas as pd

from modules.data_loader import load_dataset
from modules.prediction import (
    build_comparison_table,
    detect_task_type,
    is_ml_feasible,
    prepare_ml_data,
    run_classification_comparison,
    run_regression_comparison,
    select_candidate_features,
)


def test_ml_feasibility_rejects_small_data():
    df = pd.DataFrame({"a": range(5), "b": range(5)})
    feasible, reason = is_ml_feasible(df)
    assert not feasible


def test_detect_task_type_classification():
    series = pd.Series(["yes", "no", "yes", "no"] * 20)
    assert detect_task_type(series) == "classification"


def test_detect_task_type_regression():
    series = pd.Series(np.random.default_rng(9).normal(0, 1, 200))
    assert detect_task_type(series) == "regression"


def test_select_candidate_features_excludes_identifiers(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    features = select_candidate_features(loaded.dataframe, "Segment", loaded.column_types)
    assert "CustomerID" not in features
    assert "Segment" not in features


def test_classification_pipeline_runs(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    target = "Segment"
    task_type = detect_task_type(loaded.dataframe[target])
    features = select_candidate_features(loaded.dataframe, target, loaded.column_types)

    prepared = prepare_ml_data(loaded.dataframe, target, features, task_type)
    results = run_classification_comparison(prepared)
    table = build_comparison_table(results, task_type)

    assert not table.empty
    assert "Accuracy" in table.columns


def test_regression_pipeline_runs(csv_bytes):
    loaded = load_dataset(csv_bytes, "sample.csv")
    target = "Income"
    task_type = detect_task_type(loaded.dataframe[target])
    features = select_candidate_features(loaded.dataframe, target, loaded.column_types)

    prepared = prepare_ml_data(loaded.dataframe, target, features, task_type)
    results = run_regression_comparison(prepared)
    table = build_comparison_table(results, task_type)

    assert not table.empty
    assert "R2" in table.columns
