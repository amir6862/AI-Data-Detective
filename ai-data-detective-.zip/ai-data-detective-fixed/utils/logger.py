"""Shared logging setup.

The logger is intentionally quiet about dataset contents. Modules should
log actions and shapes, never raw values from an uploaded file.
"""

import logging
import sys

_CONFIGURED = False


def get_logger(name: str) -> logging.Logger:
    global _CONFIGURED

    if not _CONFIGURED:
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
            stream=sys.stdout,
        )
        _CONFIGURED = True

    return logging.getLogger(name)
