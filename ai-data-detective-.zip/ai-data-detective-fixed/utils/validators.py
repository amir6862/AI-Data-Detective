"""Validation helpers used before a dataset is accepted for analysis."""

from __future__ import annotations

import pandas as pd

from config.config import MAX_UPLOAD_SIZE_MB, SUPPORTED_EXTENSIONS


class DatasetValidationError(Exception):
    """Raised when an uploaded dataset cannot be safely analyzed."""


def validate_file_extension(filename: str) -> None:
    lowered = filename.lower()
    if not lowered.endswith(SUPPORTED_EXTENSIONS):
        allowed = ", ".join(SUPPORTED_EXTENSIONS)
        raise DatasetValidationError(
            f"Unsupported file type. Please upload one of: {allowed}"
        )


def validate_file_size(size_bytes: int) -> None:
    size_mb = size_bytes / (1024 * 1024)
    if size_mb > MAX_UPLOAD_SIZE_MB:
        raise DatasetValidationError(
            f"File is too large ({size_mb:.1f} MB). "
            f"The limit is {MAX_UPLOAD_SIZE_MB} MB."
        )


def validate_dataframe(df: pd.DataFrame) -> None:
    if df is None:
        raise DatasetValidationError("The file could not be read.")

    if df.shape[1] == 0:
        raise DatasetValidationError("The dataset has no columns.")

    if df.shape[0] == 0:
        raise DatasetValidationError("The dataset has no rows.")

    if df.shape[1] == 1:
        # Not fatal, but worth surfacing to the caller through a soft signal.
        pass

    duplicate_columns = df.columns[df.columns.duplicated()].tolist()
    if duplicate_columns:
        raise DatasetValidationError(
            f"The dataset has duplicate column names: {duplicate_columns}. "
            "Please rename them before uploading."
        )

    if df.columns.isnull().any() or any(str(c).strip() == "" for c in df.columns):
        raise DatasetValidationError("The dataset contains unnamed or blank column headers.")
