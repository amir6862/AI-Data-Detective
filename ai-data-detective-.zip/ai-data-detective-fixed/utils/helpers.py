"""Small reusable helpers used throughout the analysis modules."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from config.config import HIGH_CARDINALITY_RATIO, MIN_HIGH_CARDINALITY_UNIQUE


@dataclass
class ColumnTypes:
    numerical: list = field(default_factory=list)
    categorical: list = field(default_factory=list)
    datetime: list = field(default_factory=list)
    text: list = field(default_factory=list)
    identifier_like: list = field(default_factory=list)


def classify_columns(df: pd.DataFrame, text_unique_ratio: float = 0.5) -> ColumnTypes:
    """Split columns into rough functional categories.

    The classification is heuristic on purpose: it is meant to steer the
    rest of the pipeline (which chart to draw, which column to offer as a
    feature) rather than to be a strict schema.
    """

    result = ColumnTypes()
    row_count = max(len(df), 1)

    for column in df.columns:
        series = df[column]

        if pd.api.types.is_datetime64_any_dtype(series):
            result.datetime.append(column)
            continue

        if pd.api.types.is_numeric_dtype(series):
            if looks_like_identifier(series, row_count):
                result.identifier_like.append(column)
            result.numerical.append(column)
            continue

        if pd.api.types.is_bool_dtype(series):
            result.categorical.append(column)
            continue

        parsed_dates = try_parse_datetime(series)
        if parsed_dates is not None:
            result.datetime.append(column)
            continue

        unique_ratio = series.nunique(dropna=True) / row_count
        if looks_like_identifier(series, row_count):
            result.identifier_like.append(column)

        if unique_ratio >= text_unique_ratio and series.nunique(dropna=True) > 30:
            result.text.append(column)
        else:
            result.categorical.append(column)

    return result


def looks_like_identifier(series: pd.Series, row_count: int) -> bool:
    unique_count = series.nunique(dropna=True)
    if row_count < 10:
        return False

    near_unique = unique_count >= row_count * HIGH_CARDINALITY_RATIO
    if not near_unique or unique_count < MIN_HIGH_CARDINALITY_UNIQUE:
        return False

    name = str(series.name).lower()
    name_hints = ("id", "uuid", "key", "code", "number", "no.", "identifier")
    if any(hint in name for hint in name_hints):
        return True

    return near_unique


def try_parse_datetime(series: pd.Series, sample_size: int = 50):
    if series.dropna().empty:
        return None

    sample = series.dropna().astype(str).head(sample_size)
    try:
        parsed = pd.to_datetime(sample, errors="coerce", format="mixed")
    except (ValueError, TypeError):
        return None

    success_ratio = parsed.notna().mean()
    if success_ratio >= 0.9:
        return pd.to_datetime(series, errors="coerce", format="mixed")

    return None


def is_textual_dtype(series: pd.Series) -> bool:
    """True for plain string/object columns, across pandas' string backends."""

    if pd.api.types.is_numeric_dtype(series) or pd.api.types.is_bool_dtype(series):
        return False
    if pd.api.types.is_datetime64_any_dtype(series):
        return False
    return pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    if denominator == 0 or pd.isna(denominator):
        return default
    return numerator / denominator


def format_percentage(value: float, decimals: int = 1) -> str:
    return f"{value:.{decimals}f}%"


def format_number(value: float) -> str:
    if pd.isna(value):
        return "N/A"
    if float(value).is_integer():
        return f"{int(value):,}"
    return f"{value:,.2f}"


def human_readable_bytes(num_bytes: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if num_bytes < 1024:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.1f} TB"


def truncate_column_name(name: str, max_length: int = 24) -> str:
    name = str(name)
    if len(name) <= max_length:
        return name
    return name[: max_length - 3] + "..."
