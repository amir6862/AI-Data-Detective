"""Detects unusual observations using univariate and multivariate methods."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from config.config import IQR_MULTIPLIER, RANDOM_STATE, ZSCORE_THRESHOLD
from utils.helpers import safe_divide


@dataclass
class AnomalyResult:
    method: str
    anomaly_indices: list
    anomaly_count: int
    anomaly_percentage: float
    contributing_columns: list
    anomalies: pd.DataFrame


def detect_iqr_outliers(df: pd.DataFrame, column: str) -> AnomalyResult:
    series = df[column].dropna()
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - IQR_MULTIPLIER * iqr
    upper_bound = q3 + IQR_MULTIPLIER * iqr

    mask = (df[column] < lower_bound) | (df[column] > upper_bound)
    indices = df[mask].index.tolist()

    return AnomalyResult(
        method="IQR",
        anomaly_indices=indices,
        anomaly_count=len(indices),
        anomaly_percentage=round(safe_divide(len(indices), len(df)) * 100, 2),
        contributing_columns=[column],
        anomalies=df.loc[indices],
    )


def detect_zscore_outliers(df: pd.DataFrame, column: str, threshold: float = ZSCORE_THRESHOLD) -> AnomalyResult:
    series = df[column]
    mean = series.mean()
    std = series.std()

    if std == 0 or pd.isna(std):
        return AnomalyResult("Z-Score", [], 0, 0.0, [column], df.iloc[0:0])

    z_scores = (series - mean) / std
    mask = z_scores.abs() > threshold
    indices = df[mask].index.tolist()

    return AnomalyResult(
        method="Z-Score",
        anomaly_indices=indices,
        anomaly_count=len(indices),
        anomaly_percentage=round(safe_divide(len(indices), len(df)) * 100, 2),
        contributing_columns=[column],
        anomalies=df.loc[indices],
    )


def detect_isolation_forest_outliers(
    df: pd.DataFrame, columns: list, contamination="auto"
) -> AnomalyResult:
    working = df[columns].dropna()

    if len(working) < 10 or len(columns) < 2:
        return AnomalyResult("Isolation Forest", [], 0, 0.0, columns, df.iloc[0:0])

    scaler = StandardScaler()
    scaled = scaler.fit_transform(working)

    model = IsolationForest(
        contamination=contamination, random_state=RANDOM_STATE, n_estimators=200
    )
    predictions = model.fit_predict(scaled)
    anomaly_mask = predictions == -1
    indices = working.index[anomaly_mask].tolist()

    return AnomalyResult(
        method="Isolation Forest",
        anomaly_indices=indices,
        anomaly_count=len(indices),
        anomaly_percentage=round(safe_divide(len(indices), len(df)) * 100, 2),
        contributing_columns=columns,
        anomalies=df.loc[indices],
    )


def choose_anomaly_strategy(numerical_columns: list) -> str:
    if len(numerical_columns) >= 2:
        return "isolation_forest"
    if len(numerical_columns) == 1:
        return "univariate"
    return "none"


def run_automatic_anomaly_detection(df: pd.DataFrame, numerical_columns: list) -> dict:
    """Runs the appropriate strategy automatically and returns a summary.

    Always includes per-column IQR results (cheap and interpretable) and
    adds an Isolation Forest pass when there are at least two numerical
    columns to combine.
    """

    results = {"per_column": {}, "multivariate": None, "combined_indices": set()}

    for column in numerical_columns:
        if df[column].dropna().empty:
            continue
        iqr_result = detect_iqr_outliers(df, column)
        results["per_column"][column] = iqr_result
        results["combined_indices"].update(iqr_result.anomaly_indices)

    strategy = choose_anomaly_strategy(numerical_columns)
    if strategy == "isolation_forest":
        multivariate_result = detect_isolation_forest_outliers(df, numerical_columns)
        results["multivariate"] = multivariate_result
        results["combined_indices"].update(multivariate_result.anomaly_indices)

    results["combined_count"] = len(results["combined_indices"])
    results["combined_percentage"] = round(
        safe_divide(len(results["combined_indices"]), len(df)) * 100, 2
    )

    return results
