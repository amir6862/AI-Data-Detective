"""Finds and explains relationships between numerical columns."""

from __future__ import annotations

import pandas as pd

from config.config import MODERATE_CORRELATION_THRESHOLD, STRONG_CORRELATION_THRESHOLD


def compute_correlation_matrix(df: pd.DataFrame, columns: list, method: str = "pearson") -> pd.DataFrame:
    if len(columns) < 2:
        return pd.DataFrame()
    return df[columns].corr(method=method)


def choose_correlation_method(df: pd.DataFrame, columns: list) -> str:
    """Prefer Spearman when relationships are unlikely to be linear.

    A simple, explainable heuristic: if more than half of the numerical
    columns are heavily skewed, rank-based correlation is more robust.
    """

    skewed_count = 0
    for column in columns:
        series = df[column].dropna()
        if len(series) > 2 and abs(series.skew()) > 1.0:
            skewed_count += 1

    if columns and skewed_count / len(columns) > 0.5:
        return "spearman"
    return "pearson"


def find_significant_relationships(
    correlation_matrix: pd.DataFrame, threshold: float = STRONG_CORRELATION_THRESHOLD
) -> pd.DataFrame:
    if correlation_matrix.empty:
        return pd.DataFrame(columns=["Column A", "Column B", "Correlation", "Strength", "Direction"])

    records = []
    columns = correlation_matrix.columns.tolist()

    for i, col_a in enumerate(columns):
        for col_b in columns[i + 1:]:
            value = correlation_matrix.loc[col_a, col_b]
            if pd.isna(value):
                continue

            strength = _classify_strength(value, threshold)
            if strength == "Weak":
                continue

            records.append(
                {
                    "Column A": col_a,
                    "Column B": col_b,
                    "Correlation": round(float(value), 3),
                    "Strength": strength,
                    "Direction": "Positive" if value > 0 else "Negative",
                }
            )

    result = pd.DataFrame(records)
    if not result.empty:
        result = result.reindex(result["Correlation"].abs().sort_values(ascending=False).index)
        result = result.reset_index(drop=True)

    return result


def _classify_strength(value: float, strong_threshold: float) -> str:
    magnitude = abs(value)
    if magnitude >= strong_threshold:
        return "Strong"
    if magnitude >= MODERATE_CORRELATION_THRESHOLD:
        return "Moderate"
    return "Weak"


def explain_relationship(row: pd.Series) -> str:
    direction_word = "increases" if row["Direction"] == "Positive" else "decreases"
    return (
        f"As {row['Column A']} increases, {row['Column B']} tends to {direction_word} "
        f"({row['Strength'].lower()} {row['Direction'].lower()} relationship, "
        f"correlation = {row['Correlation']}). This is a statistical association only "
        f"and does not by itself imply that one causes the other."
    )
