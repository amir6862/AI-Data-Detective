"""Reads uploaded datasets and returns a clean, validated DataFrame."""

from __future__ import annotations

import io
from dataclasses import dataclass

import pandas as pd

from utils.helpers import classify_columns, ColumnTypes
from utils.logger import get_logger
from utils.validators import DatasetValidationError, validate_dataframe

logger = get_logger(__name__)

CSV_ENCODINGS_TO_TRY = ("utf-8", "utf-8-sig", "latin-1", "cp1252")
CSV_SEPARATORS_TO_TRY = (",", ";", "\t", "|")


@dataclass
class LoadedDataset:
    dataframe: pd.DataFrame
    original_dataframe: pd.DataFrame
    filename: str
    column_types: ColumnTypes
    encoding_used: str | None = None
    warnings: list | None = None

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


def load_dataset(file_bytes: bytes, filename: str) -> LoadedDataset:
    """Load a CSV or Excel file into a validated LoadedDataset.

    Raises DatasetValidationError with a user-friendly message on failure.
    Never lets a raw pandas/parsing exception escape.
    """

    lowered = filename.lower()
    warnings: list[str] = []

    try:
        if lowered.endswith(".csv"):
            df, encoding_used = _read_csv(file_bytes)
        elif lowered.endswith((".xlsx", ".xls")):
            df = _read_excel(file_bytes, lowered)
            encoding_used = None
        else:
            raise DatasetValidationError(
                "Unsupported file type. Please upload a CSV or Excel file."
            )
    except DatasetValidationError:
        raise
    except Exception as exc:  # noqa: BLE001 - we deliberately convert to a friendly error
        logger.exception("Failed to parse uploaded file %s", filename)
        raise DatasetValidationError(
            "The file appears to be corrupted or is not a valid CSV/Excel file."
        ) from exc

    df = _drop_fully_empty_rows_and_columns(df, warnings)
    validate_dataframe(df)

    original_df = df.copy(deep=True)
    df = _coerce_datetime_columns(df, warnings)

    column_types = classify_columns(df)

    return LoadedDataset(
        dataframe=df,
        original_dataframe=original_df,
        filename=filename,
        column_types=column_types,
        encoding_used=encoding_used,
        warnings=warnings,
    )


def _read_csv(file_bytes: bytes) -> tuple[pd.DataFrame, str]:
    last_error: Exception | None = None
    fallback: tuple[pd.DataFrame, str] | None = None

    for encoding in CSV_ENCODINGS_TO_TRY:
        for separator in CSV_SEPARATORS_TO_TRY:
            try:
                candidate = pd.read_csv(
                    io.BytesIO(file_bytes),
                    encoding=encoding,
                    sep=separator,
                    engine="python",
                    on_bad_lines="skip",
                )
            except (UnicodeDecodeError, pd.errors.ParserError, ValueError) as exc:
                last_error = exc
                continue

            if candidate.shape[1] > 1:
                return candidate, encoding

            if fallback is None and separator == "," and candidate.shape[1] == 1:
                fallback = (candidate, encoding)

        # Once an encoding successfully parses at all (even as one column),
        # trying further encodings won't reveal a different delimiter.
        if fallback is not None:
            break

    if fallback is not None:
        return fallback

    if last_error is not None:
        raise DatasetValidationError(
            "Could not detect a valid encoding or delimiter for this CSV file."
        )

    raise DatasetValidationError("The CSV file could not be read.")


def _read_excel(file_bytes: bytes, lowered_filename: str) -> pd.DataFrame:
    engine = "openpyxl" if lowered_filename.endswith(".xlsx") else None
    try:
        sheets = pd.read_excel(io.BytesIO(file_bytes), sheet_name=None, engine=engine)
    except ImportError as exc:
        raise DatasetValidationError(
            "Reading .xls files requires the xlrd package to be installed."
        ) from exc

    if not sheets:
        raise DatasetValidationError("The Excel file has no readable sheets.")

    non_empty_sheets = {name: sheet for name, sheet in sheets.items() if not sheet.empty}
    if not non_empty_sheets:
        raise DatasetValidationError("Every sheet in the Excel file is empty.")

    first_sheet_name = next(iter(non_empty_sheets))
    return non_empty_sheets[first_sheet_name]


def _drop_fully_empty_rows_and_columns(df: pd.DataFrame, warnings: list) -> pd.DataFrame:
    before_rows, before_cols = df.shape
    df = df.dropna(axis=0, how="all").dropna(axis=1, how="all")

    if df.shape[0] < before_rows:
        warnings.append(f"Removed {before_rows - df.shape[0]} completely empty rows.")
    if df.shape[1] < before_cols:
        warnings.append(f"Removed {before_cols - df.shape[1]} completely empty columns.")

    df.columns = [str(c).strip() for c in df.columns]
    return df.reset_index(drop=True)


def _coerce_datetime_columns(df: pd.DataFrame, warnings: list) -> pd.DataFrame:
    from utils.helpers import is_textual_dtype, try_parse_datetime

    for column in df.columns:
        if is_textual_dtype(df[column]):
            parsed = try_parse_datetime(df[column])
            if parsed is not None:
                df[column] = parsed

    return df
