"""Core data-quality detective.

Every function here returns plain data structures (dicts / DataFrames) so
the Streamlit pages stay free of analysis logic.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from config.config import (
    MISSING_LOW_THRESHOLD,
    MISSING_MODERATE_THRESHOLD,
    NEAR_CONSTANT_THRESHOLD,
)
from utils.helpers import ColumnTypes, is_textual_dtype, looks_like_identifier, safe_divide


@dataclass
class QualityReport:
    missing_summary: pd.DataFrame
    duplicate_count: int
    duplicate_percentage: float
    duplicate_examples: pd.DataFrame
    constant_columns: list
    near_constant_columns: dict
    high_cardinality_columns: list
    identifier_columns: list
    dtype_issues: list
    invalid_value_findings: list
    health_score: int
    health_breakdown: dict = field(default_factory=dict)


def analyze_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    row_count = max(len(df), 1)
    records = []

    for column in df.columns:
        missing_count = int(df[column].isna().sum())
        missing_pct = safe_divide(missing_count, row_count) * 100
        records.append(
            {
                "Column": column,
                "Missing Count": missing_count,
                "Missing %": round(missing_pct, 2),
                "Category": _missingness_category(missing_pct),
            }
        )

    return pd.DataFrame(records)


def _missingness_category(missing_pct: float) -> str:
    if missing_pct == 0:
        return "No missing values"
    if missing_pct < MISSING_LOW_THRESHOLD:
        return "Low missingness"
    if missing_pct < MISSING_MODERATE_THRESHOLD:
        return "Moderate missingness"
    return "High missingness"


def analyze_duplicates(df: pd.DataFrame) -> tuple[int, float, pd.DataFrame]:
    duplicated_mask = df.duplicated(keep=False)
    duplicate_count = int(df.duplicated().sum())
    duplicate_pct = safe_divide(duplicate_count, max(len(df), 1)) * 100
    examples = df[duplicated_mask].head(10)
    return duplicate_count, round(duplicate_pct, 2), examples


def find_constant_columns(df: pd.DataFrame) -> list:
    return [col for col in df.columns if df[col].nunique(dropna=True) <= 1]


def find_near_constant_columns(df: pd.DataFrame, exclude: list) -> dict:
    findings = {}
    for column in df.columns:
        if column in exclude:
            continue
        non_null = df[column].dropna()
        if non_null.empty:
            continue
        dominant_share = non_null.value_counts(normalize=True).iloc[0]
        if dominant_share >= NEAR_CONSTANT_THRESHOLD:
            findings[column] = round(dominant_share * 100, 2)
    return findings


def find_high_cardinality_columns(df: pd.DataFrame, column_types: ColumnTypes) -> list:
    candidates = column_types.categorical + column_types.text
    row_count = max(len(df), 1)
    findings = []

    for column in candidates:
        unique_ratio = safe_divide(df[column].nunique(dropna=True), row_count)
        if unique_ratio >= 0.5 and df[column].nunique(dropna=True) >= 20:
            findings.append(
                {
                    "Column": column,
                    "Unique Values": int(df[column].nunique(dropna=True)),
                    "Unique Ratio": round(unique_ratio * 100, 2),
                }
            )
    return findings


def find_identifier_columns(df: pd.DataFrame) -> list:
    row_count = max(len(df), 1)
    return [col for col in df.columns if looks_like_identifier(df[col], row_count)]


def find_dtype_issues(df: pd.DataFrame) -> list:
    """Look for numeric-looking data that pandas parsed as text."""

    findings = []
    for column in df.columns:
        if not is_textual_dtype(df[column]):
            continue

        non_null = df[column].dropna().astype(str).str.strip()
        if non_null.empty:
            continue

        cleaned = non_null.str.replace(",", "", regex=False)
        cleaned = cleaned.str.replace("%", "", regex=False)
        numeric_like = pd.to_numeric(cleaned, errors="coerce")
        numeric_ratio = numeric_like.notna().mean()

        if numeric_ratio >= 0.9:
            findings.append(
                {
                    "Column": column,
                    "Issue": "Stored as text but values look numeric",
                    "Numeric-like Ratio": round(numeric_ratio * 100, 2),
                }
            )

    return findings


def find_invalid_values(df: pd.DataFrame, column_types: ColumnTypes) -> list:
    """Flag values that are implausible given common-sense column semantics.

    This is deliberately conservative: it only reports a finding when a
    column name gives a strong hint about its meaning and the values
    violate an obvious constraint.
    """

    findings = []

    for column in column_types.numerical:
        series = df[column].dropna()
        if series.empty:
            continue

        name = str(column).lower()

        if any(hint in name for hint in ("age",)):
            invalid = series[(series < 0) | (series > 120)]
            if len(invalid) > 0:
                findings.append(_invalid_finding(column, invalid, "implausible age values"))

        if any(hint in name for hint in ("percent", "pct", "%")):
            invalid = series[(series < 0) | (series > 100)]
            if len(invalid) > 0:
                findings.append(_invalid_finding(column, invalid, "percentages outside 0-100"))

        if any(hint in name for hint in ("quantity", "qty", "count", "orders", "units")):
            invalid = series[series < 0]
            if len(invalid) > 0:
                findings.append(_invalid_finding(column, invalid, "negative quantities"))

        if any(hint in name for hint in ("price", "income", "salary", "revenue", "cost", "amount")):
            invalid = series[series < 0]
            if len(invalid) > 0:
                findings.append(_invalid_finding(column, invalid, "negative monetary values"))

    for column in column_types.datetime:
        series = df[column].dropna()
        if series.empty:
            continue
        future_cutoff = pd.Timestamp.now() + pd.Timedelta(days=1)
        invalid = series[series > future_cutoff]
        if len(invalid) > 0:
            findings.append(_invalid_finding(column, invalid, "dates in the future"))

    return findings


def _invalid_finding(column: str, invalid_values: pd.Series, description: str) -> dict:
    return {
        "Column": column,
        "Issue": description,
        "Count": int(len(invalid_values)),
    }


def calculate_health_score(
    df: pd.DataFrame,
    missing_summary: pd.DataFrame,
    duplicate_pct: float,
    constant_columns: list,
    high_cardinality_columns: list,
    dtype_issues: list,
    outlier_ratio: float,
) -> tuple[int, dict]:
    """Deterministic 0-100 dataset health score.

    Score starts at 100 and loses points for each category of problem,
    proportional to how severe that problem is. The weights are fixed so
    the same dataset always produces the same score.
    """

    score = 100.0
    breakdown = {}

    avg_missing_pct = missing_summary["Missing %"].mean() if not missing_summary.empty else 0.0
    missing_penalty = min(avg_missing_pct * 0.6, 30.0)
    score -= missing_penalty
    breakdown["Missing values"] = -round(missing_penalty, 1)

    duplicate_penalty = min(duplicate_pct * 0.8, 20.0)
    score -= duplicate_penalty
    breakdown["Duplicate rows"] = -round(duplicate_penalty, 1)

    constant_penalty = min(len(constant_columns) * 3.0, 15.0)
    score -= constant_penalty
    breakdown["Constant columns"] = -round(constant_penalty, 1)

    cardinality_penalty = min(len(high_cardinality_columns) * 2.0, 10.0)
    score -= cardinality_penalty
    breakdown["High-cardinality columns"] = -round(cardinality_penalty, 1)

    dtype_penalty = min(len(dtype_issues) * 4.0, 15.0)
    score -= dtype_penalty
    breakdown["Data-type issues"] = -round(dtype_penalty, 1)

    outlier_penalty = min(outlier_ratio * 100 * 0.5, 10.0)
    score -= outlier_penalty
    breakdown["Outliers"] = -round(outlier_penalty, 1)

    score = max(0, min(100, round(score)))
    return int(score), breakdown


def run_full_quality_analysis(
    df: pd.DataFrame, column_types: ColumnTypes, outlier_ratio: float = 0.0
) -> QualityReport:
    missing_summary = analyze_missing_values(df)
    duplicate_count, duplicate_pct, duplicate_examples = analyze_duplicates(df)
    constant_columns = find_constant_columns(df)
    near_constant_columns = find_near_constant_columns(df, exclude=constant_columns)
    high_cardinality_columns = find_high_cardinality_columns(df, column_types)
    identifier_columns = find_identifier_columns(df)
    dtype_issues = find_dtype_issues(df)
    invalid_value_findings = find_invalid_values(df, column_types)

    health_score, breakdown = calculate_health_score(
        df=df,
        missing_summary=missing_summary,
        duplicate_pct=duplicate_pct,
        constant_columns=constant_columns,
        high_cardinality_columns=high_cardinality_columns,
        dtype_issues=dtype_issues,
        outlier_ratio=outlier_ratio,
    )

    return QualityReport(
        missing_summary=missing_summary,
        duplicate_count=duplicate_count,
        duplicate_percentage=duplicate_pct,
        duplicate_examples=duplicate_examples,
        constant_columns=constant_columns,
        near_constant_columns=near_constant_columns,
        high_cardinality_columns=high_cardinality_columns,
        identifier_columns=identifier_columns,
        dtype_issues=dtype_issues,
        invalid_value_findings=invalid_value_findings,
        health_score=health_score,
        health_breakdown=breakdown,
    )
