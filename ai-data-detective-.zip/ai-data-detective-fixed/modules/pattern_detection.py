"""Rule-based pattern detective.

Every finding is derived from an actual statistical test or calculation.
Nothing here is invented or templated without underlying numbers.
"""

from __future__ import annotations

import pandas as pd
from scipy import stats as scipy_stats

from utils.helpers import safe_divide


def detect_group_differences(
    df: pd.DataFrame, categorical_column: str, numerical_column: str, min_group_size: int = 5
) -> list:
    findings = []
    grouped = df.dropna(subset=[categorical_column, numerical_column]).groupby(categorical_column)[
        numerical_column
    ]

    group_means = grouped.mean()
    group_sizes = grouped.size()
    valid_groups = group_sizes[group_sizes >= min_group_size].index

    if len(valid_groups) < 2:
        return findings

    overall_mean = df[numerical_column].mean()
    top_group = group_means.loc[valid_groups].idxmax()
    bottom_group = group_means.loc[valid_groups].idxmin()

    top_value = group_means.loc[top_group]
    bottom_value = group_means.loc[bottom_group]

    if overall_mean and abs(top_value - overall_mean) / abs(overall_mean) > 0.1:
        pct_diff = safe_divide(top_value - overall_mean, overall_mean) * 100
        findings.append(
            {
                "type": "high_performing_category",
                "title": f"{top_group} stands out in {numerical_column}",
                "explanation": (
                    f"The '{top_group}' group in {categorical_column} has an average "
                    f"{numerical_column} of {top_value:.2f}, which is {pct_diff:.1f}% "
                    f"above the overall average of {overall_mean:.2f}."
                ),
                "statistic": round(top_value, 2),
            }
        )

    if overall_mean and abs(bottom_value - overall_mean) / abs(overall_mean) > 0.1 and bottom_group != top_group:
        pct_diff = safe_divide(bottom_value - overall_mean, overall_mean) * 100
        findings.append(
            {
                "type": "low_performing_category",
                "title": f"{bottom_group} lags behind in {numerical_column}",
                "explanation": (
                    f"The '{bottom_group}' group in {categorical_column} has an average "
                    f"{numerical_column} of {bottom_value:.2f}, which is {pct_diff:.1f}% "
                    f"relative to the overall average of {overall_mean:.2f}."
                ),
                "statistic": round(bottom_value, 2),
            }
        )

    if len(valid_groups) == 2:
        group_a, group_b = valid_groups
        sample_a = grouped.get_group(group_a)
        sample_b = grouped.get_group(group_b)
        if len(sample_a) > 1 and len(sample_b) > 1:
            _, p_value = scipy_stats.ttest_ind(sample_a, sample_b, equal_var=False)
            if p_value < 0.05:
                findings.append(
                    {
                        "type": "significant_group_difference",
                        "title": f"{group_a} and {group_b} differ significantly in {numerical_column}",
                        "explanation": (
                            f"A two-sample t-test comparing {numerical_column} between "
                            f"'{group_a}' and '{group_b}' produced a p-value of {p_value:.4f}, "
                            "suggesting the difference is unlikely to be due to chance."
                        ),
                        "statistic": round(p_value, 4),
                    }
                )

    return findings


def detect_time_trend(df: pd.DataFrame, date_column: str, value_column: str, min_points: int = 10) -> list:
    working = df[[date_column, value_column]].dropna().sort_values(date_column)
    if len(working) < min_points:
        return []

    working = working.copy()
    working["_time_index"] = range(len(working))

    slope, intercept, r_value, p_value, _ = scipy_stats.linregress(
        working["_time_index"], working[value_column]
    )

    findings = []
    if p_value < 0.05 and abs(r_value) > 0.3:
        direction = "increasing" if slope > 0 else "decreasing"
        findings.append(
            {
                "type": "time_trend",
                "title": f"{value_column} shows a {direction} trend over time",
                "explanation": (
                    f"A linear trend fit on {value_column} over time has a slope of "
                    f"{slope:.4f} per observation (r = {r_value:.2f}, p = {p_value:.4f}), "
                    f"indicating a statistically {direction} trend."
                ),
                "statistic": round(slope, 4),
            }
        )

    return findings


def detect_weekday_effect(df: pd.DataFrame, date_column: str, value_column: str) -> list:
    working = df[[date_column, value_column]].dropna()
    if len(working) < 20:
        return []

    working = working.copy()
    working["_is_weekend"] = working[date_column].dt.dayofweek >= 5

    weekday_mean = working.loc[~working["_is_weekend"], value_column].mean()
    weekend_mean = working.loc[working["_is_weekend"], value_column].mean()

    if pd.isna(weekday_mean) or pd.isna(weekend_mean) or weekday_mean == 0:
        return []

    pct_diff = safe_divide(weekend_mean - weekday_mean, weekday_mean) * 100
    if abs(pct_diff) < 10:
        return []

    comparison = "higher" if pct_diff > 0 else "lower"
    return [
        {
            "type": "seasonal_behavior",
            "title": f"Weekend {value_column} differs from weekday {value_column}",
            "explanation": (
                f"Weekend {value_column} is approximately {abs(pct_diff):.1f}% {comparison} "
                f"than weekday {value_column} on average."
            ),
            "statistic": round(pct_diff, 2),
        }
    ]


def detect_concentration(df: pd.DataFrame, categorical_column: str, threshold: float = 0.6) -> list:
    counts = df[categorical_column].value_counts(normalize=True, dropna=True)
    if counts.empty:
        return []

    top_value = counts.index[0]
    top_share = counts.iloc[0]

    if top_share >= threshold:
        return [
            {
                "type": "value_concentration",
                "title": f"'{top_value}' dominates {categorical_column}",
                "explanation": (
                    f"The value '{top_value}' accounts for {top_share * 100:.1f}% of all "
                    f"non-missing entries in {categorical_column}, indicating an unusual "
                    "concentration rather than a balanced distribution."
                ),
                "statistic": round(top_share * 100, 2),
            }
        ]

    return []


def run_pattern_detection(
    df: pd.DataFrame, categorical_columns: list, numerical_columns: list, datetime_columns: list
) -> list:
    findings = []

    for cat_col in categorical_columns:
        nunique = df[cat_col].nunique(dropna=True)
        if not (2 <= nunique <= 15):
            continue
        for num_col in numerical_columns[:5]:
            findings.extend(detect_group_differences(df, cat_col, num_col))

        findings.extend(detect_concentration(df, cat_col))

    for date_col in datetime_columns:
        for num_col in numerical_columns[:5]:
            findings.extend(detect_time_trend(df, date_col, num_col))
            findings.extend(detect_weekday_effect(df, date_col, num_col))

    return findings
