"""Builds Plotly figures for the exploratory analysis pages.

Every function returns a `plotly.graph_objects.Figure`. Sampling is applied
for large datasets so the browser does not choke on rendering.
"""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from config.config import MAX_ROWS_FOR_FULL_VISUALIZATION, VISUALIZATION_SAMPLE_SIZE

CHART_TEMPLATE = "plotly_white"


def sample_for_plotting(df: pd.DataFrame) -> pd.DataFrame:
    if len(df) <= MAX_ROWS_FOR_FULL_VISUALIZATION:
        return df
    return df.sample(VISUALIZATION_SAMPLE_SIZE, random_state=42)


def histogram(df: pd.DataFrame, column: str, bins: int = 30) -> go.Figure:
    plot_df = sample_for_plotting(df)
    fig = px.histogram(plot_df, x=column, nbins=bins, template=CHART_TEMPLATE)
    fig.update_layout(title=f"Distribution of {column}", bargap=0.05)
    return fig


def box_plot(df: pd.DataFrame, column: str, group_by: str | None = None) -> go.Figure:
    plot_df = sample_for_plotting(df)
    fig = px.box(plot_df, x=group_by, y=column, template=CHART_TEMPLATE)
    title = f"{column} by {group_by}" if group_by else f"Box Plot of {column}"
    fig.update_layout(title=title)
    return fig


def density_plot(df: pd.DataFrame, column: str) -> go.Figure:
    plot_df = sample_for_plotting(df)
    fig = px.histogram(
        plot_df, x=column, marginal="violin", nbins=40, template=CHART_TEMPLATE, opacity=0.75
    )
    fig.update_layout(title=f"Distribution Shape of {column}")
    return fig


def bar_chart(df: pd.DataFrame, column: str, top_n: int = 15) -> go.Figure:
    counts = df[column].value_counts(dropna=True).head(top_n).reset_index()
    counts.columns = [column, "count"]
    fig = px.bar(counts, x=column, y="count", template=CHART_TEMPLATE)
    fig.update_layout(title=f"Frequency of {column}", xaxis_title=column, yaxis_title="Count")
    return fig


def scatter_plot(df: pd.DataFrame, x_column: str, y_column: str, color_by: str | None = None) -> go.Figure:
    plot_df = sample_for_plotting(df)
    fig = px.scatter(
        plot_df, x=x_column, y=y_column, color=color_by, template=CHART_TEMPLATE, opacity=0.7
    )
    fig.update_layout(title=f"{y_column} vs {x_column}")
    return fig


def time_series_plot(df: pd.DataFrame, date_column: str, value_column: str) -> go.Figure:
    plot_df = df[[date_column, value_column]].dropna().sort_values(date_column)
    fig = px.line(plot_df, x=date_column, y=value_column, template=CHART_TEMPLATE)
    fig.update_layout(title=f"{value_column} Over Time")
    return fig


def correlation_heatmap(correlation_matrix: pd.DataFrame) -> go.Figure:
    fig = px.imshow(
        correlation_matrix,
        text_auto=".2f",
        color_continuous_scale="RdBu_r",
        zmin=-1,
        zmax=1,
        template=CHART_TEMPLATE,
        aspect="auto",
    )
    fig.update_layout(title="Correlation Heatmap")
    return fig


def grouped_bar_stats(df: pd.DataFrame, categorical_column: str, numerical_column: str) -> go.Figure:
    grouped = df.groupby(categorical_column, dropna=True)[numerical_column].mean().reset_index()
    grouped = grouped.sort_values(numerical_column, ascending=False)
    fig = px.bar(grouped, x=categorical_column, y=numerical_column, template=CHART_TEMPLATE)
    fig.update_layout(title=f"Average {numerical_column} by {categorical_column}")
    return fig


def cluster_scatter(df: pd.DataFrame, x_column: str, y_column: str, cluster_labels) -> go.Figure:
    plot_df = df[[x_column, y_column]].copy()
    plot_df["Cluster"] = [str(label) for label in cluster_labels]
    fig = px.scatter(
        plot_df, x=x_column, y=y_column, color="Cluster", template=CHART_TEMPLATE, opacity=0.75
    )
    fig.update_layout(title="Cluster Assignment")
    return fig


def elbow_plot(k_values: list, inertias: list) -> go.Figure:
    fig = go.Figure(data=go.Scatter(x=k_values, y=inertias, mode="lines+markers"))
    fig.update_layout(
        title="Elbow Analysis for K-Means",
        xaxis_title="Number of Clusters (K)",
        yaxis_title="Inertia",
        template=CHART_TEMPLATE,
    )
    return fig


def confusion_matrix_heatmap(matrix, labels: list) -> go.Figure:
    fig = px.imshow(
        matrix,
        x=[str(label) for label in labels],
        y=[str(label) for label in labels],
        text_auto=True,
        color_continuous_scale="Blues",
        template=CHART_TEMPLATE,
    )
    fig.update_layout(title="Confusion Matrix", xaxis_title="Predicted", yaxis_title="Actual")
    return fig


def feature_importance_bar(importance_df: pd.DataFrame, top_n: int = 15) -> go.Figure:
    top = importance_df.head(top_n).sort_values("Importance")
    fig = px.bar(top, x="Importance", y="Feature", orientation="h", template=CHART_TEMPLATE)
    fig.update_layout(title="Feature Importance")
    return fig


def actual_vs_predicted(actual, predicted) -> go.Figure:
    fig = px.scatter(x=actual, y=predicted, template=CHART_TEMPLATE, opacity=0.6,
                      labels={"x": "Actual", "y": "Predicted"})
    min_val = min(min(actual), min(predicted))
    max_val = max(max(actual), max(predicted))
    fig.add_trace(
        go.Scatter(x=[min_val, max_val], y=[min_val, max_val], mode="lines", name="Perfect Prediction")
    )
    fig.update_layout(title="Predicted vs Actual")
    return fig
