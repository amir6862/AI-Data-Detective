"""Prepares data for clustering and interprets the resulting groups."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

from config.config import MIN_ROWS_FOR_CLUSTERING
from models.clustering import (
    compute_elbow_curve,
    estimate_dbscan_eps,
    run_dbscan,
    run_kmeans,
    suggest_optimal_k,
)
from utils.helpers import ColumnTypes


@dataclass
class ClusteringPreparation:
    features_used: list
    scaled_data: np.ndarray
    scaler: StandardScaler
    valid_index: pd.Index


def is_clustering_suitable(df: pd.DataFrame, column_types: ColumnTypes) -> tuple[bool, str]:
    usable_columns = [c for c in column_types.numerical if c not in column_types.identifier_like]

    if len(df) < MIN_ROWS_FOR_CLUSTERING:
        return False, f"Clustering needs at least {MIN_ROWS_FOR_CLUSTERING} rows."
    if len(usable_columns) < 2:
        return False, "Clustering needs at least two non-identifier numerical columns."

    return True, ""


def prepare_features(df: pd.DataFrame, feature_columns: list) -> ClusteringPreparation:
    working = df[feature_columns].dropna()
    scaler = StandardScaler()
    scaled = scaler.fit_transform(working)

    return ClusteringPreparation(
        features_used=feature_columns,
        scaled_data=scaled,
        scaler=scaler,
        valid_index=working.index,
    )


def run_kmeans_pipeline(df: pd.DataFrame, feature_columns: list, n_clusters: int | None = None) -> dict:
    prep = prepare_features(df, feature_columns)
    k_values, inertias = compute_elbow_curve(prep.scaled_data)

    chosen_k = n_clusters or suggest_optimal_k(prep.scaled_data)
    labels, model = run_kmeans(prep.scaled_data, chosen_k)

    return {
        "algorithm": "K-Means",
        "features_used": feature_columns,
        "k": chosen_k,
        "k_values": k_values,
        "inertias": inertias,
        "labels": labels,
        "valid_index": prep.valid_index,
        "cluster_sizes": pd.Series(labels).value_counts().sort_index().to_dict(),
        "profile": profile_clusters(df, prep.valid_index, feature_columns, labels),
    }


def run_dbscan_pipeline(df: pd.DataFrame, feature_columns: list, min_samples: int = 5) -> dict:
    prep = prepare_features(df, feature_columns)
    eps = estimate_dbscan_eps(prep.scaled_data, min_samples)
    labels, model = run_dbscan(prep.scaled_data, eps=eps, min_samples=min_samples)

    noise_count = int(np.sum(labels == -1))

    return {
        "algorithm": "DBSCAN",
        "features_used": feature_columns,
        "eps": round(eps, 4),
        "min_samples": min_samples,
        "labels": labels,
        "valid_index": prep.valid_index,
        "noise_count": noise_count,
        "noise_percentage": round(noise_count / len(labels) * 100, 2) if len(labels) else 0.0,
        "cluster_sizes": pd.Series(labels).value_counts().sort_index().to_dict(),
        "profile": profile_clusters(df, prep.valid_index, feature_columns, labels),
    }


def profile_clusters(df: pd.DataFrame, valid_index: pd.Index, feature_columns: list, labels) -> pd.DataFrame:
    working = df.loc[valid_index, feature_columns].copy()
    working["Cluster"] = labels

    overall_means = working[feature_columns].mean()
    profile_rows = []

    for cluster_id, group in working.groupby("Cluster"):
        row = {"Cluster": cluster_id, "Size": len(group)}
        for column in feature_columns:
            cluster_mean = group[column].mean()
            overall_mean = overall_means[column]
            direction = "higher" if cluster_mean > overall_mean else "lower"
            row[column] = round(cluster_mean, 2)
            row[f"{column}_direction"] = direction
        profile_rows.append(row)

    return pd.DataFrame(profile_rows)
