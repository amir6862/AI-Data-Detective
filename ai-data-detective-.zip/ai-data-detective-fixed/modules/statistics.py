"""Descriptive statistics for numerical and categorical columns."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from utils.helpers import safe_divide


def numerical_summary(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    rows = []

    for column in columns:
        series = df[column].dropna()
        if series.empty:
            continue

        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        mode_values = series.mode()

        rows.append(
            {
                "Column": column,
                "Count": int(series.count()),
                "Mean": round(series.mean(), 4),
                "Median": round(series.median(), 4),
                "Mode": round(mode_values.iloc[0], 4) if not mode_values.empty else np.nan,
                "Std Dev": round(series.std(), 4) if series.count() > 1 else 0.0,
                "Variance": round(series.var(), 4) if series.count() > 1 else 0.0,
                "Min": round(series.min(), 4),
                "Max": round(series.max(), 4),
                "Range": round(series.max() - series.min(), 4),
                "Q1": round(q1, 4),
                "Q3": round(q3, 4),
                "IQR": round(q3 - q1, 4),
                "Skewness": round(float(series.skew()), 4) if series.count() > 2 else 0.0,
                "Kurtosis": round(float(series.kurt()), 4) if series.count() > 3 else 0.0,
            }
        )

    return pd.DataFrame(rows)


def categorical_summary(df: pd.DataFrame, columns: list) -> pd.DataFrame:
    rows = []
    row_count = max(len(df), 1)

    for column in columns:
        series = df[column].dropna()
        if series.empty:
            continue

        value_counts = series.value_counts()
        top_value = value_counts.index[0]
        top_frequency = int(value_counts.iloc[0])

        rows.append(
            {
                "Column": column,
                "Unique Values": int(series.nunique()),
                "Most Frequent Value": str(top_value),
                "Frequency": top_frequency,
                "Percentage": round(safe_divide(top_frequency, row_count) * 100, 2),
            }
        )

    return pd.DataFrame(rows)


def categorical_distribution(df: pd.DataFrame, column: str, top_n: int = 15) -> pd.DataFrame:
    counts = df[column].value_counts(dropna=True).head(top_n)
    total = df[column].dropna().shape[0]

    return pd.DataFrame(
        {
            "Value": counts.index.astype(str),
            "Count": counts.values,
            "Percentage": [round(safe_divide(c, total) * 100, 2) for c in counts.values],
        }
    )


def column_deep_dive(df: pd.DataFrame, column: str) -> dict:
    series = df[column]
    non_null = series.dropna()

    if pd.api.types.is_numeric_dtype(series):
        if non_null.empty:
            return {"type": "numerical", "empty": True}

        normality_p_value = None
        if 3 <= len(non_null) <= 5000:
            try:
                _, normality_p_value = scipy_stats.shapiro(non_null)
            except ValueError:
                normality_p_value = None

        return {
            "type": "numerical",
            "empty": False,
            "summary": numerical_summary(df, [column]).iloc[0].to_dict(),
            "normality_p_value": normality_p_value,
        }

    return {
        "type": "categorical",
        "empty": non_null.empty,
        "distribution": categorical_distribution(df, column),
    }
