"""Turns calculated analysis results into natural-language insights.

The rule-based path always works and is the source of truth for numbers.
When an OpenAI API key is configured, the LLM is used only to rephrase and
connect findings that were already computed -- it is never allowed to
invent a statistic.
"""

from __future__ import annotations

import json

from config.config import OPENAI_API_KEY, OPENAI_MODEL
from utils.logger import get_logger

logger = get_logger(__name__)


def build_rule_based_insights(analysis_context: dict) -> list:
    """Compose plain-language sentences directly from computed results."""

    insights = []

    health_score = analysis_context.get("health_score")
    if health_score is not None:
        tier = _health_tier(health_score)
        insights.append(
            f"The dataset has an overall health score of {health_score}/100, "
            f"which is considered {tier}."
        )

    quality = analysis_context.get("quality_findings", {})
    high_missing = quality.get("high_missing_columns", [])
    if high_missing:
        columns_text = ", ".join(high_missing[:5])
        insights.append(
            f"The following columns have high missingness and may need attention "
            f"before modeling: {columns_text}."
        )

    duplicate_pct = quality.get("duplicate_percentage")
    if duplicate_pct:
        insights.append(f"About {duplicate_pct}% of rows are exact duplicates.")

    for relationship in analysis_context.get("top_correlations", [])[:3]:
        insights.append(relationship)

    for anomaly_note in analysis_context.get("anomaly_notes", [])[:2]:
        insights.append(anomaly_note)

    for pattern in analysis_context.get("pattern_findings", [])[:5]:
        explanation = pattern.get("explanation") if isinstance(pattern, dict) else pattern
        if explanation:
            insights.append(explanation)

    ml_summary = analysis_context.get("ml_summary")
    if ml_summary:
        insights.append(ml_summary)

    if not insights:
        insights.append(
            "No strong data-quality issues, correlations, or patterns were detected "
            "in this dataset based on the current analysis."
        )

    return insights


def _health_tier(score: int) -> str:
    if score >= 85:
        return "excellent"
    if score >= 70:
        return "good"
    if score >= 50:
        return "fair"
    return "poor"


def generate_insights(analysis_context: dict) -> dict:
    """Returns rule-based insights, optionally polished by an LLM.

    The return shape is always: {"insights": [...], "source": "rule_based" | "llm_enhanced"}.
    """

    base_insights = build_rule_based_insights(analysis_context)

    if not OPENAI_API_KEY:
        return {"insights": base_insights, "source": "rule_based"}

    try:
        enhanced = _enhance_with_openai(base_insights, analysis_context)
        return {"insights": enhanced, "source": "llm_enhanced"}
    except Exception as exc:  # noqa: BLE001
        logger.warning("OpenAI insight enhancement failed, falling back to rules: %s", exc)
        return {"insights": base_insights, "source": "rule_based"}


def _enhance_with_openai(base_insights: list, analysis_context: dict) -> list:
    from openai import OpenAI

    client = OpenAI(api_key=OPENAI_API_KEY)

    system_prompt = (
        "You are a data analysis assistant. You will be given a list of factual "
        "findings that were already calculated from a dataset. Rewrite them as "
        "clear, concise, professional sentences for a business audience. Do not "
        "invent numbers or claims that are not present in the input. Do not add "
        "new findings. Return a JSON array of strings, same length or shorter."
    )

    user_prompt = json.dumps({"findings": base_insights, "context_keys": list(analysis_context.keys())})

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.2,
        max_tokens=800,
    )

    content = response.choices[0].message.content
    parsed = json.loads(content)

    if isinstance(parsed, dict):
        parsed = parsed.get("findings", base_insights)

    if not isinstance(parsed, list) or not parsed:
        return base_insights

    return [str(item) for item in parsed]
