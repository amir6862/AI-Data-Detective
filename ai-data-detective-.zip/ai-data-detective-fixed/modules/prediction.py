"""Orchestrates the supervised machine learning workflow.

This module owns the decisions that need to happen before any model is
trained: is this a classification or regression problem, which columns are
safe to use as features, how should missing values and categoricals be
handled, and how should the data be split.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

from config.config import (
    CLASSIFICATION_MAX_UNIQUE_TARGET,
    MIN_ROWS_FOR_ML,
    RANDOM_STATE,
    TEST_SIZE,
)
from models import classification as classification_models
from models import regression as regression_models
from utils.helpers import ColumnTypes


@dataclass
class PreparedMLData:
    X_train: np.ndarray
    X_test: np.ndarray
    y_train: np.ndarray
    y_test: np.ndarray
    feature_names: list
    label_encoder: LabelEncoder | None
    task_type: str


def is_ml_feasible(df: pd.DataFrame) -> tuple[bool, str]:
    if len(df) < MIN_ROWS_FOR_ML:
        return False, f"Machine learning needs at least {MIN_ROWS_FOR_ML} rows."
    if df.shape[1] < 2:
        return False, "Machine learning needs at least one feature column plus a target."
    return True, ""


def detect_task_type(target_series: pd.Series) -> str:
    non_null = target_series.dropna()

    if pd.api.types.is_numeric_dtype(non_null):
        unique_count = non_null.nunique()
        looks_categorical = unique_count <= CLASSIFICATION_MAX_UNIQUE_TARGET and (
            unique_count / max(len(non_null), 1) < 0.05
        )
        if looks_categorical:
            return "classification"
        return "regression"

    return "classification"


def select_candidate_features(
    df: pd.DataFrame, target_column: str, column_types: ColumnTypes
) -> list:
    excluded = set(column_types.identifier_like)
    excluded.add(target_column)
    excluded.update(column_types.text)

    candidates = [c for c in df.columns if c not in excluded]
    return candidates


def prepare_ml_data(
    df: pd.DataFrame, target_column: str, feature_columns: list, task_type: str
) -> PreparedMLData:
    working = df[feature_columns + [target_column]].dropna(subset=[target_column]).copy()

    for column in working.select_dtypes(include=["datetime64[ns]", "datetime64"]).columns:
        working[column] = working[column].astype("int64") // 10**9

    numeric_features = working[feature_columns].select_dtypes(include=[np.number]).columns.tolist()
    categorical_features = [c for c in feature_columns if c not in numeric_features]

    if numeric_features:
        imputer = SimpleImputer(strategy="median")
        working[numeric_features] = imputer.fit_transform(working[numeric_features])

    for column in categorical_features:
        working[column] = working[column].astype(str).fillna("missing")
        working[column] = LabelEncoder().fit_transform(working[column])

    label_encoder = None
    y = working[target_column]
    if task_type == "classification" and not pd.api.types.is_numeric_dtype(y):
        label_encoder = LabelEncoder()
        y = label_encoder.fit_transform(y.astype(str))
    else:
        y = y.values

    X = working[feature_columns].values

    stratify = y if task_type == "classification" and len(np.unique(y)) > 1 else None

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=stratify
    )

    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    return PreparedMLData(
        X_train=X_train,
        X_test=X_test,
        y_train=y_train,
        y_test=y_test,
        feature_names=feature_columns,
        label_encoder=label_encoder,
        task_type=task_type,
    )


def run_classification_comparison(prepared: PreparedMLData) -> dict:
    results = {}
    for name, model in classification_models.get_classification_models().items():
        try:
            result = classification_models.train_and_evaluate_classifier(
                model, prepared.X_train, prepared.y_train, prepared.X_test, prepared.y_test
            )
            results[name] = result
        except Exception as exc:  # noqa: BLE001
            results[name] = {"error": str(exc)}
    return results


def run_regression_comparison(prepared: PreparedMLData) -> dict:
    results = {}
    for name, model in regression_models.get_regression_models().items():
        try:
            result = regression_models.train_and_evaluate_regressor(
                model, prepared.X_train, prepared.y_train, prepared.X_test, prepared.y_test
            )
            results[name] = result
        except Exception as exc:  # noqa: BLE001
            results[name] = {"error": str(exc)}
    return results


def build_comparison_table(results: dict, task_type: str) -> pd.DataFrame:
    rows = []
    for name, result in results.items():
        if "error" in result:
            continue
        row = {"Model": name}
        row.update(result["metrics"])
        rows.append(row)

    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame(rows)
    sort_column = "Accuracy" if task_type == "classification" else "R2"
    if sort_column in df.columns:
        df = df.sort_values(sort_column, ascending=False).reset_index(drop=True)
    return df


def compute_permutation_importance(model, prepared: PreparedMLData, scoring: str | None = None) -> pd.DataFrame:
    result = permutation_importance(
        model,
        prepared.X_test,
        prepared.y_test,
        n_repeats=10,
        random_state=RANDOM_STATE,
        scoring=scoring,
    )

    df = pd.DataFrame(
        {
            "Feature": prepared.feature_names,
            "Importance": result.importances_mean,
        }
    )
    return df.sort_values("Importance", ascending=False).reset_index(drop=True)
