"""Builds the final PDF investigation report."""

from __future__ import annotations

import io

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    ListFlowable,
    ListItem,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

STYLES = getSampleStyleSheet()

HEADING_STYLE = ParagraphStyle(
    "SectionHeading", parent=STYLES["Heading1"], spaceAfter=10, textColor=colors.HexColor("#1f2937")
)
SUBHEADING_STYLE = ParagraphStyle(
    "SubHeading", parent=STYLES["Heading2"], spaceAfter=6, textColor=colors.HexColor("#374151")
)
BODY_STYLE = ParagraphStyle("Body", parent=STYLES["Normal"], spaceAfter=6, leading=14)


def _dataframe_to_table(df: pd.DataFrame, max_rows: int = 15) -> Table:
    display_df = df.head(max_rows)
    data = [list(display_df.columns)] + display_df.astype(str).values.tolist()

    table = Table(data, repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTSIZE", (0, 0), (-1, -1), 7.5),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#d1d5db")),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f3f4f6")]),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]
        )
    )
    return table


def generate_report(context: dict) -> bytes:
    """Builds the PDF report and returns the raw bytes.

    `context` is a plain dict assembled by the Reports page containing the
    overview, quality report, statistics, correlations, anomalies,
    patterns, clustering, ML results, feature importance, and insights.
    """

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        topMargin=0.6 * inch,
        bottomMargin=0.6 * inch,
        leftMargin=0.6 * inch,
        rightMargin=0.6 * inch,
    )

    story = []
    story.append(Paragraph("AI Data Detective — Investigation Report", HEADING_STYLE))
    story.append(Paragraph(f"Dataset: {context.get('filename', 'Uploaded dataset')}", BODY_STYLE))
    story.append(Spacer(1, 0.2 * inch))

    _add_overview_section(story, context)
    _add_quality_section(story, context)
    _add_statistics_section(story, context)
    _add_correlation_section(story, context)
    _add_anomaly_section(story, context)
    _add_pattern_section(story, context)
    _add_clustering_section(story, context)
    _add_ml_section(story, context)
    _add_insights_section(story, context)

    doc.build(story)
    buffer.seek(0)
    return buffer.read()


def _add_overview_section(story: list, context: dict) -> None:
    overview = context.get("overview")
    if not overview:
        return

    story.append(Paragraph("1. Dataset Overview", SUBHEADING_STYLE))
    lines = [
        f"Rows: {overview.row_count:,}",
        f"Columns: {overview.column_count}",
        f"Numerical columns: {overview.numerical_count}",
        f"Categorical columns: {overview.categorical_count}",
        f"Datetime columns: {overview.datetime_count}",
        f"Missing values: {overview.missing_percentage:.2f}%",
        f"Duplicate rows: {overview.duplicate_row_count} ({overview.duplicate_row_percentage:.2f}%)",
    ]
    story.append(ListFlowable([ListItem(Paragraph(line, BODY_STYLE)) for line in lines], bulletType="bullet"))
    story.append(Spacer(1, 0.15 * inch))


def _add_quality_section(story: list, context: dict) -> None:
    quality = context.get("quality")
    if not quality:
        return

    story.append(Paragraph("2. Data Quality Analysis", SUBHEADING_STYLE))
    story.append(
        Paragraph(
            f"Dataset health score: {quality.health_score}/100. "
            f"Duplicate rows: {quality.duplicate_percentage:.2f}%. "
            f"Constant columns: {len(quality.constant_columns)}. "
            f"High-cardinality columns: {len(quality.high_cardinality_columns)}.",
            BODY_STYLE,
        )
    )

    if not quality.missing_summary.empty:
        story.append(Paragraph("Missing Values by Column", BODY_STYLE))
        story.append(_dataframe_to_table(quality.missing_summary))
    story.append(Spacer(1, 0.15 * inch))


def _add_statistics_section(story: list, context: dict) -> None:
    numerical_stats = context.get("numerical_stats")
    if numerical_stats is None or numerical_stats.empty:
        return

    story.append(Paragraph("3. Statistical Summary", SUBHEADING_STYLE))
    story.append(_dataframe_to_table(numerical_stats))
    story.append(Spacer(1, 0.15 * inch))


def _add_correlation_section(story: list, context: dict) -> None:
    correlations = context.get("correlations")
    if correlations is None or correlations.empty:
        return

    story.append(Paragraph("4. Correlation Findings", SUBHEADING_STYLE))
    story.append(_dataframe_to_table(correlations))
    story.append(
        Paragraph(
            "Note: correlation measures statistical association only and does not imply causation.",
            BODY_STYLE,
        )
    )
    story.append(Spacer(1, 0.15 * inch))


def _add_anomaly_section(story: list, context: dict) -> None:
    anomaly_summary = context.get("anomaly_summary")
    if not anomaly_summary:
        return

    story.append(Paragraph("5. Anomaly Findings", SUBHEADING_STYLE))
    story.append(
        Paragraph(
            f"Combined potential anomalies: {anomaly_summary.get('combined_count', 0)} "
            f"({anomaly_summary.get('combined_percentage', 0)}% of rows).",
            BODY_STYLE,
        )
    )
    story.append(Spacer(1, 0.15 * inch))


def _add_pattern_section(story: list, context: dict) -> None:
    patterns = context.get("patterns")
    if not patterns:
        return

    story.append(Paragraph("6. Pattern Findings", SUBHEADING_STYLE))
    items = [ListItem(Paragraph(p["explanation"], BODY_STYLE)) for p in patterns[:10]]
    story.append(ListFlowable(items, bulletType="bullet"))
    story.append(Spacer(1, 0.15 * inch))


def _add_clustering_section(story: list, context: dict) -> None:
    clustering = context.get("clustering")
    if not clustering:
        return

    story.append(Paragraph("7. Clustering Results", SUBHEADING_STYLE))
    story.append(
        Paragraph(
            f"Algorithm: {clustering.get('algorithm')}. "
            f"Features used: {', '.join(clustering.get('features_used', []))}.",
            BODY_STYLE,
        )
    )
    profile = clustering.get("profile")
    if profile is not None and not profile.empty:
        story.append(_dataframe_to_table(profile))
    story.append(Spacer(1, 0.15 * inch))


def _add_ml_section(story: list, context: dict) -> None:
    ml_results = context.get("ml_comparison")
    if ml_results is None or ml_results.empty:
        return

    story.append(Paragraph("8. Machine Learning Results", SUBHEADING_STYLE))
    story.append(_dataframe_to_table(ml_results))

    feature_importance = context.get("feature_importance")
    if feature_importance is not None and not feature_importance.empty:
        story.append(Paragraph("Feature Importance", BODY_STYLE))
        story.append(_dataframe_to_table(feature_importance))
    story.append(Spacer(1, 0.15 * inch))


def _add_insights_section(story: list, context: dict) -> None:
    insights = context.get("insights")
    if not insights:
        return

    story.append(PageBreak())
    story.append(Paragraph("9. AI-Generated Insights and Recommendations", SUBHEADING_STYLE))
    items = [ListItem(Paragraph(insight, BODY_STYLE)) for insight in insights]
    story.append(ListFlowable(items, bulletType="bullet"))
