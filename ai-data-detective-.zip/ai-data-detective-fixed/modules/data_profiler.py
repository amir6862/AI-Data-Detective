"""Builds the high-level dataset overview and the column information table."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from utils.helpers import ColumnTypes, human_readable_bytes, safe_divide


@dataclass
class DatasetOverview:
    row_count: int
    column_count: int
    memory_usage: str
    numerical_count: int
    categorical_count: int
    datetime_count: int
    text_count: int
    missing_percentage: float
    duplicate_row_count: int
    duplicate_row_percentage: float


def build_overview(df: pd.DataFrame, column_types: ColumnTypes) -> DatasetOverview:
    total_cells = df.shape[0] * df.shape[1]
    missing_cells = int(df.isna().sum().sum())
    duplicate_rows = int(df.duplicated().sum())

    return DatasetOverview(
        row_count=df.shape[0],
        column_count=df.shape[1],
        memory_usage=human_readable_bytes(df.memory_usage(deep=True).sum()),
        numerical_count=len(column_types.numerical),
        categorical_count=len(column_types.categorical),
        datetime_count=len(column_types.datetime),
        text_count=len(column_types.text),
        missing_percentage=safe_divide(missing_cells, total_cells) * 100,
        duplicate_row_count=duplicate_rows,
        duplicate_row_percentage=safe_divide(duplicate_rows, df.shape[0]) * 100,
    )


def build_column_info_table(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    row_count = max(len(df), 1)

    for column in df.columns:
        series = df[column]
        missing_count = int(series.isna().sum())
        non_null = series.dropna()
        example_values = non_null.astype(str).unique()[:3]

        rows.append(
            {
                "Column": column,
                "Data Type": str(series.dtype),
                "Unique Values": int(series.nunique(dropna=True)),
                "Missing Values": missing_count,
                "Missing %": round(safe_divide(missing_count, row_count) * 100, 2),
                "Example Values": ", ".join(example_values) if len(example_values) else "N/A",
            }
        )

    return pd.DataFrame(rows)


def get_row_sample(df: pd.DataFrame, mode: str, n: int = 10) -> pd.DataFrame:
    if mode == "first":
        return df.head(n)
    if mode == "last":
        return df.tail(n)
    if mode == "random":
        sample_size = min(n, len(df))
        if sample_size == 0:
            return df
        return df.sample(sample_size, random_state=42)
    raise ValueError(f"Unknown row sample mode: {mode}")
