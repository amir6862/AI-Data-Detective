"""AI Data Detective - main Streamlit application."""

import streamlit as st

from config.config import APP_NAME
from modules.data_loader import load_dataset
from utils.logger import get_logger
from utils.validators import DatasetValidationError, validate_file_extension, validate_file_size

from app_pages import (
    anomalies,
    clustering,
    correlations,
    dashboard,
    exploration,
    insights,
    machine_learning,
    overview,
    patterns,
    quality,
    reports,
    statistics as statistics_page,
)

logger = get_logger(__name__)

NAV_PAGES = {
    "Dashboard": dashboard,
    "Dataset Overview": overview,
    "Data Quality": quality,
    "Statistics": statistics_page,
    "Exploratory Analysis": exploration,
    "Correlations": correlations,
    "Anomalies": anomalies,
    "Patterns": patterns,
    "Clustering": clustering,
    "Machine Learning": machine_learning,
    "AI Insights": insights,
    "Reports": reports,
}


def configure_page() -> None:
    st.set_page_config(page_title=APP_NAME, layout="wide")
    st.markdown(
        """
        <style>
        .block-container {padding-top: 2rem; padding-bottom: 2rem;}
        div[data-testid="stMetricValue"] {font-size: 1.6rem;}
        </style>
        """,
        unsafe_allow_html=True,
    )


def init_session_state() -> None:
    defaults = {
        "dataset": None,
        "target_column": None,
        "ml_results_cache": {},
        "clustering_cache": {},
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def render_sidebar() -> str:
    with st.sidebar:
        st.title(APP_NAME)
        st.caption("An automated data investigation platform")

        st.markdown("---")
        uploaded_file = st.file_uploader(
            "Upload a dataset", type=["csv", "xlsx", "xls"], key="file_uploader"
        )

        if uploaded_file is not None:
            handle_upload(uploaded_file)

        st.markdown("---")

        if st.session_state["dataset"] is None:
            st.info("Upload a dataset to unlock the navigation menu.")
            return "Dashboard"

        selected_page = st.radio("Navigation", list(NAV_PAGES.keys()), label_visibility="collapsed")

        st.markdown("---")
        dataset = st.session_state["dataset"]
        st.caption(f"Loaded file: {dataset.filename}")
        st.caption(f"Rows: {dataset.dataframe.shape[0]:,} | Columns: {dataset.dataframe.shape[1]}")

        return selected_page


def handle_upload(uploaded_file) -> None:
    current_dataset = st.session_state.get("dataset")
    if current_dataset is not None and current_dataset.filename == uploaded_file.name:
        if getattr(current_dataset, "_size_marker", None) == uploaded_file.size:
            return

    try:
        validate_file_extension(uploaded_file.name)
        validate_file_size(uploaded_file.size)
        file_bytes = uploaded_file.getvalue()
        loaded_dataset = load_dataset(file_bytes, uploaded_file.name)
        loaded_dataset._size_marker = uploaded_file.size

        st.session_state["dataset"] = loaded_dataset
        st.session_state["target_column"] = None
        st.session_state["ml_results_cache"] = {}
        st.session_state["clustering_cache"] = {}

        if loaded_dataset.warnings:
            for warning in loaded_dataset.warnings:
                st.sidebar.warning(warning)

    except DatasetValidationError as exc:
        st.sidebar.error(str(exc))
    except Exception:  # noqa: BLE001
        logger.exception("Unexpected error while loading uploaded file")
        st.sidebar.error(
            "Something went wrong while reading this file. "
            "Please check the file format and try again."
        )


def main() -> None:
    configure_page()
    init_session_state()

    selected_page = render_sidebar()

    if st.session_state["dataset"] is None:
        dashboard.render_empty_state()
        return

    page_module = NAV_PAGES[selected_page]
    try:
        page_module.render(st.session_state["dataset"])
    except Exception:  # noqa: BLE001
        logger.exception("Unhandled error while rendering page %s", selected_page)
        st.error(
            "This page ran into an unexpected error while analyzing the dataset. "
            "Try a different dataset or adjust your selections."
        )


if __name__ == "__main__":
    main()
