"""Trains and evaluates classification models."""

from __future__ import annotations

import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.tree import DecisionTreeClassifier

from config.config import RANDOM_STATE

try:
    from xgboost import XGBClassifier

    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False


def get_classification_models() -> dict:
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
        "Decision Tree": DecisionTreeClassifier(random_state=RANDOM_STATE, max_depth=8),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, random_state=RANDOM_STATE, max_depth=None
        ),
        "Gradient Boosting": GradientBoostingClassifier(random_state=RANDOM_STATE),
    }

    if XGBOOST_AVAILABLE:
        models["XGBoost"] = XGBClassifier(
            random_state=RANDOM_STATE, eval_metric="logloss", verbosity=0
        )

    return models


def train_and_evaluate_classifier(model, X_train, y_train, X_test, y_test) -> dict:
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    is_binary = len(np.unique(y_train)) == 2
    average_method = "binary" if is_binary else "weighted"

    metrics = {
        "Accuracy": round(accuracy_score(y_test, predictions), 4),
        "Precision": round(precision_score(y_test, predictions, average=average_method, zero_division=0), 4),
        "Recall": round(recall_score(y_test, predictions, average=average_method, zero_division=0), 4),
        "F1 Score": round(f1_score(y_test, predictions, average=average_method, zero_division=0), 4),
    }

    roc_auc = None
    if is_binary and hasattr(model, "predict_proba"):
        try:
            probabilities = model.predict_proba(X_test)[:, 1]
            roc_auc = round(roc_auc_score(y_test, probabilities), 4)
        except (ValueError, IndexError):
            roc_auc = None

    if roc_auc is not None:
        metrics["ROC-AUC"] = roc_auc

    conf_matrix = confusion_matrix(y_test, predictions)

    return {
        "model": model,
        "predictions": predictions,
        "metrics": metrics,
        "confusion_matrix": conf_matrix,
        "classes": model.classes_,
    }


def get_feature_importance(model, feature_names: list) -> "pd.DataFrame":
    import pandas as pd

    if hasattr(model, "feature_importances_"):
        importances = model.feature_importances_
    elif hasattr(model, "coef_"):
        importances = np.abs(model.coef_).flatten()
        if len(importances) != len(feature_names):
            importances = importances[: len(feature_names)]
    else:
        return pd.DataFrame(columns=["Feature", "Importance"])

    df = pd.DataFrame({"Feature": feature_names, "Importance": importances})
    return df.sort_values("Importance", ascending=False).reset_index(drop=True)


def detect_class_imbalance(y) -> dict:
    import pandas as pd

    counts = pd.Series(y).value_counts(normalize=True)
    is_imbalanced = counts.iloc[0] > 0.75 if len(counts) > 0 else False

    return {
        "is_imbalanced": bool(is_imbalanced),
        "class_distribution": counts.round(4).to_dict(),
        "majority_share": round(float(counts.iloc[0]), 4) if len(counts) > 0 else 0.0,
    }
