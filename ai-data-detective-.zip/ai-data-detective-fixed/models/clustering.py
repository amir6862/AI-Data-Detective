"""Thin wrappers around scikit-learn clustering estimators."""

from __future__ import annotations

import numpy as np
from sklearn.cluster import DBSCAN, KMeans
from sklearn.metrics import silhouette_score

from config.config import DBSCAN_MIN_SAMPLES, MAX_KMEANS_K, RANDOM_STATE


def run_kmeans(scaled_data: np.ndarray, n_clusters: int) -> tuple[np.ndarray, KMeans]:
    model = KMeans(n_clusters=n_clusters, random_state=RANDOM_STATE, n_init=10)
    labels = model.fit_predict(scaled_data)
    return labels, model


def compute_elbow_curve(scaled_data: np.ndarray, max_k: int = MAX_KMEANS_K) -> tuple[list, list]:
    max_k = min(max_k, len(scaled_data) - 1) if len(scaled_data) > 2 else 2
    max_k = max(max_k, 2)

    k_values = list(range(2, max_k + 1))
    inertias = []

    for k in k_values:
        model = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
        model.fit(scaled_data)
        inertias.append(model.inertia_)

    return k_values, inertias


def suggest_optimal_k(scaled_data: np.ndarray, max_k: int = MAX_KMEANS_K) -> int:
    """Pick K using silhouette score, falling back to 3 for small datasets."""

    max_k = min(max_k, len(scaled_data) - 1)
    if max_k < 2:
        return 2

    best_k = 2
    best_score = -1.0

    for k in range(2, max_k + 1):
        model = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
        labels = model.fit_predict(scaled_data)
        if len(set(labels)) < 2:
            continue
        score = silhouette_score(scaled_data, labels)
        if score > best_score:
            best_score = score
            best_k = k

    return best_k


def run_dbscan(scaled_data: np.ndarray, eps: float = 0.5, min_samples: int = DBSCAN_MIN_SAMPLES):
    model = DBSCAN(eps=eps, min_samples=min_samples)
    labels = model.fit_predict(scaled_data)
    return labels, model


def estimate_dbscan_eps(scaled_data: np.ndarray, min_samples: int = DBSCAN_MIN_SAMPLES) -> float:
    """Rough eps estimate using the average distance to the k-th nearest neighbor."""

    from sklearn.neighbors import NearestNeighbors

    n_neighbors = min(min_samples, len(scaled_data) - 1)
    if n_neighbors < 1:
        return 0.5

    neighbors = NearestNeighbors(n_neighbors=n_neighbors)
    neighbors.fit(scaled_data)
    distances, _ = neighbors.kneighbors(scaled_data)
    k_distances = np.sort(distances[:, -1])
    return float(np.percentile(k_distances, 90)) or 0.5
